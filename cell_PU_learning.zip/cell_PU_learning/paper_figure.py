import glob
import cv2
import numpy as np 
import numpy.matlib
import os
import re
import copy
from pyheatmap.heatmap import HeatMap
import torch as t
import torch.nn.functional as F




if __name__ == "__main__":
    # root = '../data/data_proc/colorectal_adenocarcinomas/'
    # root = '../data/data_proc/honeybee/'
    root = '../data/data_proc/part_B/'

    # root = '../data/data_proc/colorectal_adenocarcinomas_old/'
    dataset = 'test'
    img_dir = root + dataset + '/imgs/imgs_2/'
    img_file = ['2']
    img_height,img_width = 384,512
    num_samples = 12
    kernel_size = 15

    img_list = glob.glob(img_dir + '*.jpg')


    for _img_add in img_list:
        
        if _img_add.split('\\')[-1].split('.')[0] != 'IMG_147':#'beeType1_008':#IMG_230;img17;IMG_184
            continue

        img = cv2.imread(_img_add)
        label_dir = _img_add.split('\\')[-1].split('.')[0] +'.txt'
        label = np.loadtxt(root + dataset + '/labels/' + label_dir)

        print('number of labels: %d'%(len(label)))

        mask = np.zeros((img_height,img_width))
        mask = np.array(mask,dtype = np.uint8)
        # mask = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)

        np.random.seed(666)
        # rand_index = np.random.permutation(label.shape[0])[0:num_samples]
        # label = label[rand_index,:]

        for i in range(label.shape[0]):
            # cv2.circle(img, (int(label[i][0]+0.5),int(label[i][1]+0.5)) ,6,(0,250,0),-1)
            index = (int(label[i][0]+0.5),int(label[i][1]+0.5))
            cv2.drawMarker(img,index,(50,250,50),markerType = cv2.MARKER_TILTED_CROSS,markerSize = 10,thickness = 6)
            
        radius = kernel_size//2
        for i in range(len(label)):
            index = (min(int(label[i][1]+0.5),img_height-1),min(int(label[i][0]+0.5),img_width-1))

            r1 = max(0, index[0] - radius)
            r2 = min(index[0] + radius + 1, img_height-1)
            c1 = max(0, index[1] - radius)
            c2 = min(index[1] + radius + 1, img_width-1)
            # cv2.rectangle(img, (c1,r1), (c2, r2), 0, -1)
            # mask[r1:r2,c1:c2] = 255  #注意0，1可能会相反
            cv2.circle(mask,(index[1],index[0]),2,110,-1)
            # mask[index[0],index[1]] = 255  #注意0，1可能会相反
            # label_object[index[0],index[1]] = 1

        # mask = np.array(mask,dtype = np.uint8)
        # mask = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)

        # overlapping = cv2.addWeighted(img, 0.2, mask, 0.8, 0)

        hm = cv2.applyColorMap(mask,cv2.COLORMAP_JET)

        cv2.imshow('img', img)
        cv2.imshow('mask', hm)
        cv2.waitKey()
        cv2.imwrite('img.png',img)
        cv2.imwrite('mask.png',hm)

        img_r27 = cv2.transpose(img)
        img_r27 = cv2.flip(img_r27,1)
        cv2.imwrite('img_r27.png',img_r27)

        mask_r27 = cv2.transpose(mask)
        mask_r27 = cv2.flip(mask_r27,1)
        cv2.imwrite('mask_r27.png',mask_r27)