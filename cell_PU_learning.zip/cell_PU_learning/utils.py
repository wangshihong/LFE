import torch as t
import torch.nn as nn
import torch.nn.functional as F
import scipy.stats as stats
import numpy as np
from sklearn.metrics import confusion_matrix
import itertools
import time
import random
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import cv2
import copy
import os
import glob
import shutil
from models.dataset import get_obejct_background, RandomTransform

def dataset_split(img_dir, label_dir, split_num):

    train_dir = './train/'
    validate_dir = './validate/'
    test_dir = './test/'

    if os.path.exists(train_dir):
        shutil.rmtree(train_dir)
    if os.path.exists(validate_dir):
        shutil.rmtree(validate_dir)
    if os.path.exists(test_dir):
        shutil.rmtree(test_dir)

    train_img_dir = train_dir + 'imgs/'
    train_label_dir = train_dir + 'labels/'
    os.makedirs(train_img_dir)
    os.makedirs(train_label_dir)

    validate_img_dir = validate_dir + 'imgs/'
    validate_label_dir = validate_dir + 'labels/'
    os.makedirs(validate_img_dir)
    os.makedirs(validate_label_dir)

    test_img_dir = test_dir + 'imgs/'
    test_label_dir = test_dir + 'labels/'
    os.makedirs(test_img_dir)
    os.makedirs(test_label_dir)
    

    img_list = glob.glob(img_dir + '*[jpg,bmp,png,pgm]')

    img_num = len(img_list)

    train_num = split_num[0]
    validate_num = split_num[1]

    index_seq = list(range(img_num))

    random.shuffle(index_seq)

    for i in range(img_num):
        img_name = img_list[index_seq[i]].split('/')[-1]
        label_name = img_name.split('.')[0] + '_detection.txt'
        if i < train_num:
            shutil.copyfile(img_list[index_seq[i]],train_img_dir + img_name)
            shutil.copyfile(label_dir + label_name,train_label_dir + label_name)
        elif i < train_num + validate_num:
            shutil.copyfile(img_list[index_seq[i]],validate_img_dir + img_name)
            shutil.copyfile(label_dir + label_name,validate_label_dir + label_name)
        else:
            shutil.copyfile(img_list[index_seq[i]],test_img_dir + img_name)
            shutil.copyfile(label_dir + label_name,test_label_dir + label_name)


class Logger(object):
    '''Save training process to log file with simple plot function.'''
    def __init__(self, fpath, title=None, resume=False): 
        self.file = None
        self.resume = resume
        self.title = '' if title == None else title
        if fpath is not None:
            if resume: 
                self.file = open(fpath, 'r') 
                name = self.file.readline()
                self.names = name.rstrip().split('\t')
                self.numbers = {}
                for _, name in enumerate(self.names):
                    self.numbers[name] = []

                for numbers in self.file:
                    numbers = numbers.rstrip().split('\t')
                    for i in range(0, len(numbers)):
                        self.numbers[self.names[i]].append(numbers[i])
                self.file.close()
                self.file = open(fpath, 'a')  
            else:
                self.file = open(fpath, 'w')

    def set_names(self, names):
        if self.resume: 
            pass
        # initialize numbers as empty list
        self.numbers = {}
        self.names = names
        for _, name in enumerate(self.names):
            self.file.write(name)
            self.file.write('\t')
            self.numbers[name] = []
        self.file.write('\n')
        self.file.flush()


    def append(self, numbers):
        assert len(self.names) == len(numbers), 'Numbers do not match names'
        for index, num in enumerate(numbers):
            self.file.write("{0:.6f}".format(num))
            self.file.write('\t')
            self.numbers[self.names[index]].append(num)
        self.file.write('\n')
        self.file.flush()

    def plot(self, names=None):   
        names = self.names if names == None else names
        numbers = self.numbers
        for _, name in enumerate(names):
            x = np.arange(len(numbers[name]))
            plt.plot(x, np.asarray(numbers[name]))
        plt.legend([self.title + '(' + name + ')' for name in names])
        plt.grid(True)

    def close(self):
        if self.file is not None:
            self.file.close()

def location(density, kernel_size):
    
    count = density.sum()
    count_int = int(round(count))
    result = []
    for i in range(count_int):

        index = np.where(density == density.max())
        result.append([index[1][0],index[0][0]])
        cv2.circle(density,(index[1][0],index[0][0]), (kernel_size+1)//2, 0,-1)

    return result

def distance_sq(gt_pos,pre_pos):
    
    # gt_pos  2*M  
    # pre_pos 2*N
    # output  M*N

    N_gt = gt_pos.shape[1]
    N_pre = pre_pos.shape[1]
    gt2 = (gt_pos**2).sum(0)
    gt2 = gt2[np.newaxis,:]
    pre2 = (pre_pos**2).sum(0)
    pre2 = pre2[np.newaxis,:]

    X2 = np.kron(gt2.T,np.ones([1,N_pre]))
    Y2 = np.kron(pre2,np.ones([N_gt,1]))
    _2XY = 2*np.dot(gt_pos.T,pre_pos)
    dis_mat = X2 + Y2 - _2XY

    return dis_mat

def location_eval(outputs_density, dot_labels, r_thd, kernel_size):
    
    TP_seq = []
    FP_seq = []
    TN_seq = []
    dis_seq = []
    count_pre = []
    count_gt = []

    batchsize = outputs_density.shape[0]
    for i in range(batchsize):
        density = outputs_density[i,:,:]
        dot_label = dot_labels[i,:,:]

        count_pre.append(density.sum())
        count_gt.append(dot_label.sum())

        pre_pos = np.array(location(density, kernel_size))             #N*2
        gt_location = np.where(dot_label==1)
        gt_pos = np.vstack((gt_location[1],gt_location[0])).T   #N*2

        ori_pre_pos = copy.deepcopy(pre_pos)

        if min(pre_pos.shape) == 0:
            TP_seq.append(0)
            FP_seq.append(0)
            TN_seq.append(gt_pos.shape[0])
            continue
        if min(gt_pos.shape) == 0:
            TP_seq.append(0)
            FP_seq.append(pre_pos.shape[0])
            TN_seq.append(0)
            continue

        all_dis_mat = np.sqrt(distance_sq(pre_pos.T,gt_pos.T))
        dis_seq.extend(all_dis_mat.min(1))

        TP = 0
        for i in range(gt_pos.shape[0]):
            gt_loc = np.array([gt_pos[i,:]])
            if pre_pos.shape[0] == 0:
                continue
            dis_mat = np.sqrt(distance_sq(gt_loc.T,pre_pos.T))
            
            if dis_mat.min() < r_thd:
                TP += 1
                idex = np.where(dis_mat == dis_mat.min())
                pre_pos =  np.delete(pre_pos,idex[1],0)
                # dis_seq.append(dis_mat.min())
        

        density = density/max([density.max(),0.0001])*255
        density = np.array(density,dtype = np.uint8)

        TP_seq.append(TP)
        TN = gt_pos.shape[0] - TP
        TN_seq.append(TN)
        FP = ori_pre_pos.shape[0] - TP
        FP_seq.append(FP)


    count_pre = np.array(count_pre)
    count_gt = np.array(count_gt)
    
    me = np.median(dis_seq)#中位数
    q1 = np.percentile(dis_seq,25)#25%分位数
    q3 = np.percentile(dis_seq,75)#25%分位数
    # print('me: %.4f, q1: %.4f, q3: %.4f'%(me,q1,q3))

    mae = (abs(count_pre-count_gt)).mean()
    mse = np.sqrt(((count_pre-count_gt)**2).mean())

    # print('Average number of cells: %.2f'%(count_gt.mean()))
    # print('mae: %.2f and mse: %.2f'%(mae,mse))

    total_tp = np.array(TP_seq).sum()
    total_tn = np.array(TN_seq).sum()
    total_fp = np.array(FP_seq).sum()
    total_p = total_tp + total_fp
    if total_p == 0:
        total_p += 0.01
    total_precision  = total_tp / total_p
    total_recall = total_tp / (total_tp + total_tn)
    
    to = total_precision + total_recall
    if to == 0:
        to += 0.01 
    F1 = 2*total_precision*total_recall/to

    eval_res = {}
    eval_res['mae'] = mae
    eval_res['mse'] = mse
    eval_res['me'] = me
    eval_res['q1'] = q1
    eval_res['q3'] = q3
    eval_res['precision'] = total_precision
    eval_res['recall'] = total_recall
    eval_res['F1'] = F1

    # print('\n~~~~~~~~~~~~~~~~~~~~~~~')
    # print(F1)
    # print(mae)
    return eval_res

def location_from_density(density, delete_labels, loss_prob, kernel_size):
    
    # density_show = density/max([density.max(),0.0001])*255
    # density_show = np.array(density_show,dtype = np.uint8)
    # cv2.imshow('density',density_show)
    # cv2.waitKey()

    radius = kernel_size//2
    count_int = int(round(density.sum()))

    pseudo_num = min(10000, count_int - delete_labels.shape[0])
    #pseudo_num = int(np.sum(loss_prob[loss_prob > 0.5])/(kernel_size*kernel_size)+0.5)#min(10000, count_int - delete_labels.shape[0])

    img_height = density.shape[0]
    img_width = density.shape[1]

    # local_max = []
    
    for i in range(delete_labels.shape[0]):

        index = (min(int(delete_labels[i][0]+0.5),img_width-1),min(int(delete_labels[i][1]+0.5),img_height-1))  #(x,y)
        x1 = max(0, index[0] - radius)
        x2 = min(index[0] + radius + 1, img_width-1)
        y1 = max(0, index[1] - radius)
        y2 = min(index[1] + radius + 1, img_height-1)

        cv2.rectangle(density,(x1,y1), (x2, y2), 0, -1)
        

    # local_max = np.array(local_max)
    # mean_p = local_max.mean()
    # std_p = np.std(local_max)
    # thd_p = mean_p - 1*std_p
    
    result = []
    for i in range(pseudo_num):

        # if density.max() < max(0.2, thd_p):
        #     break
        if loss_prob.max() < 0.6:
           break
        index = np.where(density == density.max())
        # print(density.max())
        if loss_prob[index[0][0],index[1][0]] > 0.6:
            result.append([index[1][0],index[0][0]])
        else:
            i = i-1
            # print(i)
        
        del_index = [index[1][0],index[0][0]]  #(x,y)
        x1 = max(0, del_index[0] - radius)
        x2 = min(del_index[0] + radius + 1, img_width-1)
        y1 = max(0, del_index[1] - radius)
        y2 = min(del_index[1] + radius + 1, img_height-1)

        cv2.rectangle(density,(x1,y1), (x2, y2), 0, -1)
    #print('mean_thd: %.2f'%(low_thd)) 
    return np.array(result)


def update_labels(outputs_density, dot_labels, mask_labels, loss_prob_batch, kernel_size, num_labels, last = False):

    pseudo_dot_labels = np.zeros(dot_labels.shape)
    pseudo_mask_labels = np.ones(dot_labels.shape)

    batchsize = outputs_density.shape[0]
    pseudo_label_num = 0
    for i in range(batchsize):
        density = outputs_density[i,:,:,:].squeeze().cpu().numpy()
        dot_label = dot_labels[i,:,:,:].squeeze().cpu().numpy()
        loss_prob = loss_prob_batch[i,:,:,:].squeeze().cpu().numpy()

        # print('[%d,%d,%.2f]'%(dot_label.sum(),num_labels,density.sum()))

        if dot_label.sum() < num_labels:
            continue

        if density.sum() <= dot_label.sum():
            continue

        temp = np.where(dot_label==1)
        gt_dot_loc = np.vstack((temp[1],temp[0])).T   #N*2 (x,y)

        pseudo_dot_loc = location_from_density(density, gt_dot_loc, loss_prob, kernel_size)    #N*2 (x,y)
        pseudo_label_num += pseudo_dot_loc.size // 2

        pseudo_dot_labels[i,0,:,:], pseudo_mask_labels[i,0,:,:] = get_obejct_background(density, pseudo_dot_loc, kernel_size)
        #print('iiiiiiiiiiiiiiiiiiiii')
        #print(pseudo_dot_loc)
        #print(pseudo_dot_labels[i,0,:,:].sum())
        # # print('i am hereeeeeeeeeeeeeeeeeeeeeee!')
        # loss_mask = loss_prob
        # loss_mask[loss_mask>=0.5] = 10
        # loss_mask[loss_mask<0.5] = 1
        # loss_mask[loss_mask>1] = 0

        # pseudo_mask_labels[i,0,:,:] = loss_mask
    #print(pseudo_dot_labels.sum())
    #print('cor0000000000000 %d'%((1-pseudo_mask_labels).sum()))
    pseudo_mask_labels = pseudo_mask_labels * mask_labels.cpu().numpy()
    # pseudo_label_num = pseudo_mask_labels.sum()/(kernel_size * kernel_size)
    
    #if last is False:
     #   print('\nMean pseudo-label number is: %.2f'%(pseudo_label_num/batchsize))
    return t.from_numpy(pseudo_dot_labels), t.from_numpy(pseudo_mask_labels)
    

def randTransform(data, device, trans_mode_default = None):

    batchsize = data.shape[0]
    #mode_set = ['v','h','vh','r9','r27','r9h','r9v']
    mode_set = ['v','h','vh']
    #mode_set = ['h']
    trans_mode = []
    trans_data = np.zeros(data.shape).astype(np.float32)

    for i in range(batchsize):
        if trans_mode_default != None:
            rand_transform_mode = trans_mode_default[i]
        else:
            rand_transform_mode = mode_set[np.random.permutation(len(mode_set))[0]]
        trans_mode.append(rand_transform_mode)

        x_0 = data[i,:,:,:].cpu().numpy()
        x_1 = np.zeros((x_0.shape[1],x_0.shape[2],x_0.shape[0]))

        for j in range(x_0.shape[0]):
            x_1[:,:,j] = x_0[j,:,:]

        transformer = RandomTransform()
        inputs = {}
        inputs['transform_mode'] = rand_transform_mode
        inputs['x'] = x_1
        x_trans = transformer(inputs)
        if len(x_trans.shape) == 2:
            x_trans = np.expand_dims(x_trans, axis = 2)

        for j in range(x_trans.shape[2]):
            trans_data[i,j,:,:] = x_trans[:,:,j]
    
    trans_data = t.from_numpy(trans_data).to(device)
    
    return trans_data, trans_mode


def reverse_transform(x, mode):
    if mode == 'v':
        x = cv2.flip(x,0)
    elif mode == 'h':
        x = cv2.flip(x,1)
    elif mode == 'vh':
        x = cv2.flip(x,-1)
    elif mode == 'r9':
        x = cv2.transpose(x)
        x = cv2.flip(x, 1)
    elif mode == 'r27':
        x = cv2.transpose(x)
        x = cv2.flip(x, 0)
    elif mode == 'r9h':
        x = cv2.transpose(x)
        x = cv2.flip(cv2.flip(x,1),1)
    elif mode == 'r9v':
        # cv2.imshow('r9v',x)
        # cv2.waitKey()
        x = cv2.transpose(x)
        x = cv2.flip(cv2.flip(x,1),0)
    return x

def reverseTransform(data, trans_mode, device):

    batchsize = data.shape[0]

    reverse_data = np.zeros(data.shape).astype(np.float32)

    for i in range(batchsize):
        x = data[i,:,:,:].squeeze().cpu().numpy()
        mode = trans_mode[i]

        reverse_data[i,:,:,:] = reverse_transform(x, mode)

    reverse_data = t.from_numpy(reverse_data).to(device)

    return reverse_data


def count_data(d, patch_size, step_size = None):
    
    if step_size is None:
        step_size = patch_size
    else:
        d = F.pad(d,[patch_size//2,patch_size//2,patch_size//2,patch_size//2])

    avg_pool = t.nn.AvgPool2d(patch_size,step_size)

    return patch_size*patch_size*avg_pool(d)


def track_training_loss(model, device, train_loader, kernel_size, epoch, bmm_model1, bmm_model_maxLoss1, bmm_model_minLoss1):
    model.eval()

    all_losses = t.Tensor()

    for i, data in enumerate(train_loader):
        #print(i)
        inputs,dot_labels,mask_labels = data[0].to(device),data[1].to(device),data[2].to(device)
        density_map = model(inputs)
        local_sum_den = count_data(density_map, kernel_size, 1)
        #fore_loss = (local_sum_den - 1).pow(2).mul(1 - mask_labels)
        back_loss = t.tanh(local_sum_den).mul(mask_labels)
        #idx_loss = fore_loss + back_loss
        idx_loss = back_loss.view(-1).detach()
        all_losses = t.cat((all_losses, idx_loss.cpu()))

    loss_tr = all_losses.data.numpy()
    
    # save_loss = loss_tr.reshape(1500,10000)
    # np.savetxt('./loss.txt',save_loss,fmt = '%.2f')

    # outliers detection
    max_perc = max(0.99,loss_tr.max())
    min_perc = 0.01

    loss_tr = loss_tr[(loss_tr<=max_perc) & (loss_tr>=min_perc)]
    
    print(np.size(loss_tr))
    print(np.size(loss_tr[loss_tr>0.5]))

    bmm_model_maxLoss = t.FloatTensor([max_perc]).to(device)
    bmm_model_minLoss = t.FloatTensor([min_perc]).to(device) + 10e-6


    loss_tr = (loss_tr - bmm_model_minLoss.data.cpu().numpy()) / (bmm_model_maxLoss.data.cpu().numpy() - bmm_model_minLoss.data.cpu().numpy() + 1e-6)

    loss_tr[loss_tr>=1] = 1-10e-4
    loss_tr[loss_tr <= 0] = 10e-4

    bmm_model = BetaMixture1D(max_iters=10)
    bmm_model.fit(loss_tr)
    bmm_model.plot()
    bmm_model.create_lookup(1)

    return bmm_model, bmm_model_maxLoss, bmm_model_minLoss



def compute_probabilities_batch(density_map, mask_labels, kernel_size, bmm_model, bmm_model_maxLoss, bmm_model_minLoss):

    local_sum_den = count_data(density_map, kernel_size, 1)
    # fore_loss = (local_sum_den - 1).pow(2).mul(1 - mask_labels)
    back_loss = t.tanh(local_sum_den).mul(mask_labels)

    label_negative_mask = t.zeros(mask_labels.shape)
    label_negative_mask[back_loss<bmm_model_minLoss] = 1

    # batch_losses = fore_loss + back_loss
    batch_losses = back_loss.view(-1).detach()

    batch_losses = (batch_losses - bmm_model_minLoss) / (bmm_model_maxLoss - bmm_model_minLoss + 1e-6)
    batch_losses[batch_losses >= 1] = 1-10e-4
    batch_losses[batch_losses <= 0] = 10e-4

    #B = bmm_model.posterior(batch_losses,1)
    B = bmm_model.look_lookup(batch_losses, bmm_model_maxLoss, bmm_model_minLoss)

    B = B.reshape(density_map.shape)
    
    img_prob = B[0,:,:,:]
    img_prob = img_prob.squeeze()
    img_prob[img_prob >= 0.5] = 1
    img_prob[img_prob < 0.5] = 0
    np.savetxt('./img_prob.txt',img_prob)
    img_prob = img_prob/max([img_prob.max(),0.0001])*255
    img_prob = np.array(img_prob,dtype = np.uint8)

    cv2.imwrite('img_prob.bmp',img_prob)

    return t.FloatTensor(B), t.FloatTensor(label_negative_mask)


################### CODE FOR THE BETA MODEL  ########################

def weighted_mean(x, w):
    return np.sum(w * x) / np.sum(w)

def fit_beta_weighted(x, w):
    x_bar = weighted_mean(x, w)
    s2 = weighted_mean((x - x_bar)**2, w)
    alpha = x_bar * ((x_bar * (1 - x_bar)) / s2 - 1)
    beta = alpha * (1 - x_bar) /x_bar
    return alpha, beta


class BetaMixture1D(object):
    def __init__(self, max_iters=10,
                 alphas_init=[1, 2],
                 betas_init=[2, 1],
                 weights_init=[0.5, 0.5]):
        self.alphas = np.array(alphas_init, dtype=np.float64)
        self.betas = np.array(betas_init, dtype=np.float64)
        self.weight = np.array(weights_init, dtype=np.float64)
        self.max_iters = max_iters
        self.lookup = np.zeros(100, dtype=np.float64)
        self.lookup_resolution = 100
        self.lookup_loss = np.zeros(100, dtype=np.float64)
        self.eps_nan = 1e-12

    def likelihood(self, x, y):
        return stats.beta.pdf(x, self.alphas[y], self.betas[y])

    def weighted_likelihood(self, x, y):
        return self.weight[y] * self.likelihood(x, y)

    def probability(self, x):
        return sum(self.weighted_likelihood(x, y) for y in range(2))

    def posterior(self, x, y):
        return self.weighted_likelihood(x, y) / (self.probability(x) + self.eps_nan)

    def responsibilities(self, x):
        r =  np.array([self.weighted_likelihood(x, i) for i in range(2)])
        # there are ~200 samples below that value
        r[r <= self.eps_nan] = self.eps_nan
        r /= r.sum(axis=0)
        return r

    def score_samples(self, x):
        return -np.log(self.probability(x))

    def fit(self, x):
        x = np.copy(x)

        # EM on beta distributions unsable with x == 0 or 1
        eps = 1e-4
        x[x >= 1 - eps] = 1 - eps
        x[x <= eps] = eps

        for i in range(self.max_iters):

            # E-step
            r = self.responsibilities(x)

            # M-step
            self.alphas[0], self.betas[0] = fit_beta_weighted(x, r[0])
            self.alphas[1], self.betas[1] = fit_beta_weighted(x, r[1])
            self.weight = r.sum(axis=1)
            self.weight /= self.weight.sum()
        
        #print('weight: ')
        #print(self.weight)

        #print('alpha, beta')
        #print(self.alphas)
        #print(self.betas)
        return self

    def predict(self, x):
        return self.posterior(x, 1) > 0.5

    def create_lookup(self, y):
        x_l = np.linspace(0+self.eps_nan, 1-self.eps_nan, self.lookup_resolution)
        lookup_t = self.posterior(x_l, y)
        lookup_t[np.argmax(lookup_t):] = lookup_t.max()
        self.lookup = lookup_t
        self.lookup_loss = x_l # I do not use this one at the end

    def look_lookup(self, x, loss_max, loss_min):
        x_i = x.clone().cpu().numpy()
        x_i = np.array((self.lookup_resolution * x_i).astype(int))
        x_i[x_i < 0] = 0
        x_i[x_i == self.lookup_resolution] = self.lookup_resolution - 1
        return self.lookup[x_i]

    def plot(self):
        x = np.linspace(0, 1, 100)
        plt.plot(x, self.weighted_likelihood(x, 0), label='negative')
        plt.plot(x, self.weighted_likelihood(x, 1), label='positive')
        plt.plot(x, self.probability(x), lw=2, label='mixture')
        plt.savefig('./' + 'loss_BMM.jpg')
        plt.cla()

    def __str__(self):
        return 'BetaMixture1D(w={}, a={}, b={})'.format(self.weight, self.alphas, self.betas)
