import torch as t
import numpy as np
from sklearn.metrics import confusion_matrix
import itertools
import time
import random
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import cv2
import copy
from dataset import get_obejct_background

class Logger(object):
    '''Save training process to log file with simple plot function.'''
    def __init__(self, fpath, title=None, resume=False): 
        self.file = None
        self.resume = resume
        self.title = '' if title == None else title
        if fpath is not None:
            if resume: 
                self.file = open(fpath, 'r') 
                name = self.file.readline()
                self.names = name.rstrip().split('\t')
                self.numbers = {}
                for _, name in enumerate(self.names):
                    self.numbers[name] = []

                for numbers in self.file:
                    numbers = numbers.rstrip().split('\t')
                    for i in range(0, len(numbers)):
                        self.numbers[self.names[i]].append(numbers[i])
                self.file.close()
                self.file = open(fpath, 'a')  
            else:
                self.file = open(fpath, 'w')

    def set_names(self, names):
        if self.resume: 
            pass
        # initialize numbers as empty list
        self.numbers = {}
        self.names = names
        for _, name in enumerate(self.names):
            self.file.write(name)
            self.file.write('\t')
            self.numbers[name] = []
        self.file.write('\n')
        self.file.flush()


    def append(self, numbers):
        assert len(self.names) == len(numbers), 'Numbers do not match names'
        for index, num in enumerate(numbers):
            self.file.write("{0:.6f}".format(num))
            self.file.write('\t')
            self.numbers[self.names[index]].append(num)
        self.file.write('\n')
        self.file.flush()

    def plot(self, names=None):   
        names = self.names if names == None else names
        numbers = self.numbers
        for _, name in enumerate(names):
            x = np.arange(len(numbers[name]))
            plt.plot(x, np.asarray(numbers[name]))
        plt.legend([self.title + '(' + name + ')' for name in names])
        plt.grid(True)

    def close(self):
        if self.file is not None:
            self.file.close()


def location_from_density(density, delete_labels, kernel_size):
    
    # density_show = density/max([density.max(),0.0001])*255
    # density_show = np.array(density_show,dtype = np.uint8)
    # cv2.imshow('density',density_show)
    # cv2.waitKey()

    radius = kernel_size//2
    count_int = int(round(density.sum()))

    # pseudo_num = min(delete_labels.shape[0], count_int - delete_labels.shape[0])
    pseudo_num = min(10000, count_int - delete_labels.shape[0])

    img_height = density.shape[0]
    img_width = density.shape[1]

    low_thd = 0
    
    for i in range(delete_labels.shape[0]):

        index = (min(int(delete_labels[i][1]+0.5),img_height-1),min(int(delete_labels[i][0]+0.5),img_width-1))  #(row,col)
        r1 = max(0, index[0] - radius)
        r2 = min(index[0] + radius + 1, img_height-1)
        c1 = max(0, index[1] - radius)
        c2 = min(index[1] + radius + 1, img_width-1)
        roi_density = density[r1:r2,c1:c2]
        low_thd += roi_density.max()

        cv2.circle(density,(index[0], index[1]),radius + 1,0,-1)
        

    low_thd = low_thd/delete_labels.shape[0]
    
    result = []
    for i in range(pseudo_num):

        if density.max() < max(0.2, low_thd):
            break
        index = np.where(density == density.max())
        result.append([index[1][0],index[0][0]])
        cv2.circle(density,(index[1][0],index[0][0]),radius,0,-1)
    #print('mean_thd: %.2f'%(low_thd)) 
    return np.array(result)

# def distance_sq(gt_pos,pre_pos):
    
#     # gt_pos  2*M  
#     # pre_pos 2*N
#     # output  M*N

#     N_gt = gt_pos.shape[1]
#     N_pre = pre_pos.shape[1]
#     gt2 = (gt_pos**2).sum(0)
#     gt2 = gt2[np.newaxis,:]
#     pre2 = (pre_pos**2).sum(0)
#     pre2 = pre2[np.newaxis,:]

#     X2 = np.kron(gt2.T,np.ones([1,N_pre]))
#     Y2 = np.kron(pre2,np.ones([N_gt,1]))
#     _2XY = 2*np.dot(gt_pos.T,pre_pos)
#     dis_mat = X2 + Y2 - _2XY

#     return dis_mat

def update_labels(outputs_density, dot_labels, mask_labels, kernel_size, num_labels, last = False):

    pseudo_dot_labels = np.zeros(dot_labels.shape)
    pseudo_mask_labels = np.ones(dot_labels.shape)

    batchsize = outputs_density.shape[0]
    pseudo_label_num = 0
    for i in range(batchsize):
        density = outputs_density[i,:,:,:].squeeze().cpu().numpy()
        dot_label = dot_labels[i,:,:,:].squeeze().cpu().numpy()

        if dot_label.sum() < num_labels:
            continue

        if density.sum() <= dot_label.sum():
            continue

        temp = np.where(dot_label==1)
        gt_dot_loc = np.vstack((temp[1],temp[0])).T   #N*2 (x,y)

        pseudo_dot_loc = location_from_density(density, gt_dot_loc, kernel_size)    #N*2 (x,y)
        pseudo_label_num += pseudo_dot_loc.size // 2

        pseudo_dot_labels[i,0,:,:], pseudo_mask_labels[i,0,:,:] = get_obejct_background(density, pseudo_dot_loc, kernel_size)
    
    pseudo_mask_labels = pseudo_mask_labels.mul(mask_labels)
    
    if last is False:
        print('\nMean pseudo-label number is: %.2f'%(pseudo_label_num/batchsize))
    return t.from_numpy(pseudo_dot_labels), t.from_numpy(pseudo_mask_labels)
    
