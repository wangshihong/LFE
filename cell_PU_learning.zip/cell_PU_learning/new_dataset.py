import numpy as np
import math
import os
import re
import glob
import cv2


if __name__ == "__main__":

    num = 0
    root_dir = '../data/data_proc/small/Small Object dataset/fly/'
    img_file_dir = root_dir + 'img/'
    label_file_dir = root_dir + 'gt-dots/'

    img_list = glob.glob(img_file_dir + '*.jpg')

    for img_dir in img_list:
        img_name = img_dir.split('\\')[-1]
        label_name = 'dots' + img_name.split('.')[0].split('y')[-1] + '.png'

        label_img = cv2.imread(label_file_dir + label_name)

        gray_img = cv2.cvtColor(label_img,cv2.COLOR_BGR2GRAY)

        index = np.where(gray_img>1)
        points = np.vstack((index[1],index[0])).T

        save_name = img_name.split('.')[0] + '_detection.txt'
        np.savetxt(img_file_dir+save_name,points,fmt='%.2f')