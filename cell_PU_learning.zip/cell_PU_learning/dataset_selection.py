import numpy as np
import math
import os
import re
import glob



if __name__ == "__main__":

    num = 0
    root_dir = '../data/data_proc/'
    dataset = 'MBM_data'
    train_dir = root_dir + dataset + '/train' + '/labels/'
    validate_dir = root_dir + dataset + '/validate' + '/labels/'
    test_dir = root_dir + dataset + '/test' + '/labels/'

    train_label_list = glob.glob(train_dir + '*.txt')
    validate_label_list = glob.glob(validate_dir + '*.txt')
    test_label_list = glob.glob(test_dir + '*.txt')

    train_label_num = []
    validate_label_num = []
    test_label_num = []

    for train_label_dir in train_label_list:

        train_label = np.loadtxt(train_label_dir)
        train_label_num.append(len(train_label))

    for validate_label_dir in validate_label_list:
    
        validate_label = np.loadtxt(validate_label_dir)
        validate_label_num.append(len(validate_label))

    for test_label_dir in test_label_list:
    
        test_label = np.loadtxt(test_label_dir)
        test_label_num.append(len(test_label))

    train_label_num = np.array(train_label_num)
    validate_label_num = np.array(validate_label_num)
    test_label_num = np.array(test_label_num)

    train_num_mean = train_label_num.mean()
    validate_num_mean = validate_label_num.mean()
    test_num_mean = test_label_num.mean()

    min_value = min(train_num_mean,validate_num_mean,test_num_mean)

    print('train:validate:test = %.2f: %.2f: %.2f'%(train_num_mean, validate_num_mean, test_num_mean))
    print('train:validate:test = %.2f: %.2f: %.2f'%(train_num_mean/min_value, validate_num_mean/min_value, test_num_mean/min_value))