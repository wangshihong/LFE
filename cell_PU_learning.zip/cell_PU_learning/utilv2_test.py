import torch as t
import numpy as np
from sklearn.metrics import confusion_matrix
import itertools
import time
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import random



# confusion matrix
def plot_confusion_matrix(cm,classes,save_add,save_fig = False,normalize = False, title = 'Confusion matrix', cmap = plt.cm.Oranges): 
    if normalize:
        cm = cm.astype('float')/cm.sum(axis = 1)[:, np.newaxis]
        print('Normalized confusion matrix')
    else:
        print('confusion matrix, without normalization')
    
    print(cm)

    if save_fig == False:
        return

    plt.figure(figsize = (10,10))
    plt.imshow(cm, interpolation='nearest',cmap=cmap)
    plt.title(title,size = 24)
    plt.colorbar(aspect = 4)
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation = 0, size = 14)
    plt.yticks(tick_marks, classes, size = 14)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max()/2.

    #labeling the plot
    for i,j in itertools.product(range(cm.shape[0]),range(cm.shape[1])):
        plt.text(j,i,format(cm[i,j],fmt),fontsize = 20, horizontalalignment = 'center',color = 'white' if cm[i,j]>thresh else 'black')
    
    plt.grid(None)
    plt.tight_layout()
    plt.ylabel('True label', size = 18)
    plt.xlabel('Predicted label', size = 18)
    plt.savefig(save_add + '/confusion_matrix.jpg')
    #plt.show()

# forward validate
def test_full_img_CE(dataloader,net,device,dataset_name,save_address,save_fig = False):
    
    net.eval()

    correct = 0
    total = 0
    t_start = time.time()
    gt_labels = []
    _countings = []

    t_start = time.time()

    save_outputs = -1*np.ones([1,250000])

    #transform_modes = ['v','h','vh','r9','r27','r9h','r9v']

    with t.no_grad():
        for data in dataloader:
            
            inputs_0,labels_small,labels_large = data[0].to(device),data[1].to(device),data[2].to(device)

            outputs_density = net(inputs_0)
            ###********************************************### 
            outputs_density_0 = outputs_density[:,0,:,:].unsqueeze(1)
            outputs_density_1 = outputs_density[:,1,:,:].unsqueeze(1)
            outputs_0 = outputs_density_0.view(outputs_density_0.size()[0],-1) 
            outputs_1 = outputs_density_1.view(outputs_density_1.size()[0],-1) 
            save_outputs = np.vstack((save_outputs,outputs_0.cpu().numpy()))
            save_outputs = np.vstack((save_outputs,outputs_1.cpu().numpy()))
            print(save_outputs.shape)
        
        np.savetxt(f'./result/visual.txt',save_outputs,fmt='%0.2f')
        np.savetxt(f'./result/label.txt',gt_labels,fmt = '%d')
        
        print('----------------------------------------------------------')

    t_end = time.time()
    print('Processing time: %.2f'%(t_end-t_start))
    print('Processing velocity: '+ f'{len(gt_labels)/(t_end-t_start)} cell-imgs per second')
    print('----------------------------------------------------------')


# forward validate
def test_full_img(dataloader,net,device,dataset_name,save_address,save_fig = False):
    
    net.eval()

    correct = 0
    total = 0
    t_start = time.time()
    gt_labels = []
    _countings = []

    t_start = time.time()

    save_outputs = -1*np.ones([1,250000])

    #transform_modes = ['v','h','vh','r9','r27','r9h','r9v']

    with t.no_grad():
        for data in dataloader:
            
            inputs_0,labels_small,labels_large = data[0].to(device),data[1].to(device),data[2].to(device)

            outputs_density = net(inputs_0)
            ###********************************************### 
            outputs = outputs_density.view(outputs_density.size()[0],-1) 
            save_outputs = np.vstack((save_outputs,outputs.cpu().numpy()))
            print(save_outputs.shape)
        
        np.savetxt(f'./result/visual.txt',save_outputs,fmt='%0.2f')
        np.savetxt(f'./result/label.txt',gt_labels,fmt = '%d')
        
        print('----------------------------------------------------------')

    t_end = time.time()
    print('Processing time: %.2f'%(t_end-t_start))
    print('Processing velocity: '+ f'{len(gt_labels)/(t_end-t_start)} cell-imgs per second')
    print('----------------------------------------------------------')
