import torch as t
import torchvision as tv
import torchvision.transforms as transforms
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from datetime import datetime
import time
import os

import _init_path
from utilv2_validate import validate
import network

# set environment
os.environ["CUDA_VISIBLE_DEVICES"] = '7'
device = t.device("cuda:0" if t.cuda.is_available() else "cpu")
device_ids = [0]

if __name__ == '__main__':
    
    train_net = 'SiameseNet'
    model_file_name = 'unet_bn_bilinear_nore'
 
    if train_net == 'SiameseNet':
        count_net = network.SiameseNet()
    
    # obtain data 
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
    ])

    img_dir = '../data/data_proc/colorectal_adenocarcinomas/'
    test_img_dir = img_dir + 'train_patches_3/'

    testset = tv.datasets.ImageFolder(root = test_img_dir,transform = transform)
    testloader = t.utils.data.DataLoader(testset,
                                        batch_size = 256,pin_memory = False,
                                        shuffle = False,num_workers = 16)

    print('The numbers of samples in test dataset is: %d'%(len(testset)))

    count_net = t.nn.DataParallel(count_net,device_ids = device_ids)

    save_add = './save_model/' + train_net + '/' + model_file_name + '/'
    count_net.load_state_dict(t.load(save_add + train_net + '-epoch_54.pt'))
    
    count_net.to(device)

    #compute_accuracy(trainloader,count_net,'training set',save_add,device = device,save_fig = True)
    validate(testloader,count_net,device,'test set',save_add,save_fig = False)
