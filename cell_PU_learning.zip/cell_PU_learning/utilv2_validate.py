import torch as t
import numpy as np
from sklearn.metrics import confusion_matrix
import itertools
import time
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import random

from models.transform_data import transform_data

# print confusion matrix
def plot_confusion_matrix(cm,classes,save_add,save_fig = False,normalize = False, title = 'Confusion matrix', cmap = plt.cm.Oranges): 
    if normalize:
        cm = cm.astype('float')/cm.sum(axis = 1)[:, np.newaxis]
        print('Normalized confusion matrix')
    else:
        print('confusion matrix, without normalization')
    
    print(cm)

    if save_fig == False:
        return

    plt.figure(figsize = (10,10))
    plt.imshow(cm, interpolation='nearest',cmap=cmap)
    plt.title(title,size = 24)
    plt.colorbar(aspect = 4)
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation = 0, size = 14)
    plt.yticks(tick_marks, classes, size = 14)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max()/2.

    #labeling the plot
    for i,j in itertools.product(range(cm.shape[0]),range(cm.shape[1])):
        plt.text(j,i,format(cm[i,j],fmt),fontsize = 20, horizontalalignment = 'center',color = 'white' if cm[i,j]>thresh else 'black')
    
    plt.grid(None)
    plt.tight_layout()
    plt.ylabel('True label', size = 18)
    plt.xlabel('Predicted label', size = 18)
    plt.savefig(save_add + '/confusion_matrix.jpg')
    #plt.show()

# forward validate
def validate(dataloader,net,device,dataset_name,save_address,save_fig = False):
    
    net.eval()

    correct = 0
    total = 0
    t_start = time.time()
    gt_labels = []
    _countings = []

    save_outputs = -1*np.ones([1,625])

    transform_modes = ['v','h','vh','r9','r27','r9h']

    with t.no_grad():
        for data in dataloader:

            inputs_0,labels = data[0].to(device),data[1].to(device)
            trans_mode = transform_modes[random.sample(range(0,6),1)[0]]
            inputs_1 = transform_data(inputs_0,trans_mode)

            outputs_0, outputs_1 = net(inputs_0,inputs_1)
            ###********************************************### 
            outputs = outputs_0.view(outputs_0.size()[0],-1) 
            save_outputs = np.vstack((save_outputs,outputs.cpu().numpy()))
            print(save_outputs.shape)
            outputs = outputs.sum(1)

            ###********************************************###

            gt_labels = np.append(gt_labels,labels.cpu().numpy())
            _countings = np.append(_countings,outputs.cpu().numpy())

            total += labels.size(0)
        
        np.savetxt(f'./result/visual.txt',save_outputs,fmt='%0.2f')
        np.savetxt(f'./result/label.txt',gt_labels,fmt = '%d')
        
        print('----------------------------------------------------------')

    t_end = time.time()
    print('Processing time: %.2f'%(t_end-t_start))
    print('Processing velocity: '+ f'{len(gt_labels)/(t_end-t_start)} cell-imgs per second')

    # confusion matrix
    pre_3d = np.zeros([3,len(_countings)])
    pre_3d[0] = _countings
    pre_3d[1] = _countings
    pre_3d[2] = _countings

    lab_3d = np.zeros([3,len(_countings)])
    lab_3d[1] = 1
    lab_3d[2] = 2

    distance = np.abs(pre_3d-lab_3d)
    _predictions = np.argmin(distance,0)
    
    correct_num = (gt_labels==_predictions).sum()
    val_acc = correct_num/float(total)

    print(f'Overall accuracy in {dataset_name}: %.2f'%(val_acc*100))
    cm = confusion_matrix(gt_labels,_predictions)
    plot_confusion_matrix(cm,classes = ['Background','Empty','Single','Multiple'],
                            save_add=save_address,
                            title = f'Confusion Matrix for {dataset_name}',
                            save_fig=save_fig)

    print('----------------------------------------------------------')
    return val_acc
