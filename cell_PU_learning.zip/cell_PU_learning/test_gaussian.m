clc;
clear;

kernel_size = 9;
sigma = 2;

gaussian_kernel = zeros(kernel_size,kernel_size);

mu1 = round(kernel_size/2+0.5); mu2 = round(kernel_size/2+0.5);
for i =1:kernel_size
    for j = 1:kernel_size
        density(i,j) = gaussian2(mu1,mu2,sigma,sigma,i,j);
    end
end

density = density/sum(density(:))



function density = gaussian2(mu1,mu2,sigma1,sigma2,x,y)

% density1 = 1/(2*pi*sigma1*sigma2);
density2 = exp(-1/2*((x-mu1)^2/sigma1^2+(y-mu2)^2/sigma2^2));

density = density2;

end