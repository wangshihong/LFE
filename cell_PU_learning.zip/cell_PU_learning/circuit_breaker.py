import subprocess
import time


def circuit_breaker(temp_thd = 80, sleep_time = 3, is_record = True, save_dir = None):

    while True:

        gpu_id,gpu_temp_str = subprocess.getstatusoutput("nvidia-smi -q | grep 'GPU Current Temp' | cut -d' ' -f 24")

        if is_record and save_dir:
            temp_save_file = open(save_dir + 'temperature_record.txt','a')
            temp_save_file.write(gpu_temp_str + '\n')
            temp_save_file.close()

        gpu_temp = [int(item) for item in gpu_temp_str.split('\n')]

        if max(gpu_temp) > temp_thd:

            print('The temperature is too high! Sleep for a while...')

            time.sleep(sleep_time*60)
        
        else:

            break

