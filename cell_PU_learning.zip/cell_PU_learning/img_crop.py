import numpy as np 
import glob
from shutil import copyfile
import random
import os
import cv2
import copy

from numpy.lib.function_base import median

from numpy.core.fromnumeric import mean

# rand_seed = 64678
rand_seed = 378
if rand_seed is not None:
    os.environ['PYTHONHASHSEED'] = str(rand_seed)
    np.random.seed(rand_seed)
    random.seed(rand_seed)


def get_crop(img_width, img_height, set_width, set_height, image, labels):
    crop_img = np.zeros((set_height,set_width,3))

    if img_width <= set_width:
        lt_x = 0
        rb_x = img_width-1
        pad_x = set_width - rb_x + 1
    else:
        lt_x = np.random.randint(img_width-set_width)
        rb_x = lt_x + set_width - 1
    if img_height <= set_height:
        lt_y = 0
        rb_y = img_height - 1 
        pad_y = set_height - rb_y + 1
    else:
        lt_y = np.random.randint(img_height-set_height)
        rb_y = lt_y + set_height - 1
    
    crop_img[0:(rb_y-lt_y+1),0:(rb_x-lt_x+1),:] = image[lt_y:(rb_y+1),lt_x:(rb_x+1),:]
    crop_img = np.array(crop_img, dtype = np.uint8)
    copy_crop_img = copy.deepcopy(crop_img)
    # image = cv2.resize(image,(int(image.shape[1]/2),int(image.shape[0]/2)))
    
    ## labels
    crop_labels = []
    for j in range(labels.shape[0]):
        each_label = labels[j,:]
        if each_label[0] <= rb_x and each_label[0] >= lt_x and each_label[1] <= rb_y and each_label[1] >= lt_y:
            crop_label = [each_label[0] - lt_x, each_label[1] - lt_y]
            crop_labels.append(crop_label)
            cv2.circle(copy_crop_img,(int(crop_label[0]), int(crop_label[1])),2,(0,0,250),-1)

    cv2.imshow('copy_crop_img',copy_crop_img)
    cv2.waitKey(1)
    crop_labels = np.array(crop_labels)

    return crop_img, crop_labels


if __name__ == "__main__":

    root = '../data/data_proc/'
    data_to_proc = 'part_A'

    dataset = 'validate'

    data_dir = root + data_to_proc + '/' + dataset + '/imgs/'
    label_dir = root + data_to_proc + '/' + dataset + '/labels/'
    save_img_dir = root + data_to_proc + '/' + dataset + '/imgs_crop_2/'
    save_label_dir = root + data_to_proc + '/' + dataset + '/labels_crop_2/'

    img_list = glob.glob(data_dir + '*.jpg')

    img_num = len(img_list)

    length_x = []
    max_x_name = ''
    length_y = []
    max_y_name = ''

    set_width = 400
    set_height = 400
    num_small = []

    for i in range(img_num):
        img_name = img_list[i].split('\\')[-1]

        image = cv2.imread(img_list[i])
        labels = np.loadtxt(label_dir + img_name.split('.')[0] + '.txt')
        img_width,img_height = image.shape[1], image.shape[0]

        crop_img_1, crop_labels_1 = get_crop(img_width, img_height, set_width, set_height, image, labels)
        num_small.append(crop_labels_1.shape[0])

        crop_img_2, crop_labels_2 = get_crop(img_width, img_height, set_width, set_height, image, labels)
        num_small.append(crop_labels_2.shape[0])

        ## save
        cv2.imwrite(save_img_dir + img_name.split('.')[0] + '_1.jpg', crop_img_1)
        np.savetxt(save_label_dir + img_name.split('.')[0] + '_1.txt', crop_labels_1, fmt = '%.2f')

        cv2.imwrite(save_img_dir + img_name.split('.')[0] + '_2.jpg', crop_img_2)
        np.savetxt(save_label_dir + img_name.split('.')[0] + '_2.txt', crop_labels_2, fmt = '%.2f')
        # length_x.append(image.shape[1])
        # length_y.append(image.shape[0])

    print(mean(num_small))
