import torch as t
import numpy as np
from sklearn.metrics import confusion_matrix
import itertools
import time
import random
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import cv2
import copy

class Logger(object):
    '''Save training process to log file with simple plot function.'''
    def __init__(self, fpath, title=None, resume=False): 
        self.file = None
        self.resume = resume
        self.title = '' if title == None else title
        if fpath is not None:
            if resume: 
                self.file = open(fpath, 'r') 
                name = self.file.readline()
                self.names = name.rstrip().split('\t')
                self.numbers = {}
                for _, name in enumerate(self.names):
                    self.numbers[name] = []

                for numbers in self.file:
                    numbers = numbers.rstrip().split('\t')
                    for i in range(0, len(numbers)):
                        self.numbers[self.names[i]].append(numbers[i])
                self.file.close()
                self.file = open(fpath, 'a')  
            else:
                self.file = open(fpath, 'w')

    def set_names(self, names):
        if self.resume: 
            pass
        # initialize numbers as empty list
        self.numbers = {}
        self.names = names
        for _, name in enumerate(self.names):
            self.file.write(name)
            self.file.write('\t')
            self.numbers[name] = []
        self.file.write('\n')
        self.file.flush()


    def append(self, numbers):
        assert len(self.names) == len(numbers), 'Numbers do not match names'
        for index, num in enumerate(numbers):
            self.file.write("{0:.6f}".format(num))
            self.file.write('\t')
            self.numbers[self.names[index]].append(num)
        self.file.write('\n')
        self.file.flush()

    def plot(self, names=None):   
        names = self.names if names == None else names
        numbers = self.numbers
        for _, name in enumerate(names):
            x = np.arange(len(numbers[name]))
            plt.plot(x, np.asarray(numbers[name]))
        plt.legend([self.title + '(' + name + ')' for name in names])
        plt.grid(True)

    def close(self):
        if self.file is not None:
            self.file.close()

def location(density):
    
    count = density.sum()
    count_int = int(round(count))
    result = []
    for i in range(count_int):

        index = np.where(density == density.max())
        result.append([index[1][0],index[0][0]])
        cv2.circle(density,(index[1][0],index[0][0]),6,0,-1)

    return result

def distance_sq(gt_pos,pre_pos):
    
    # gt_pos  2*M  
    # pre_pos 2*N
    # output  M*N

    N_gt = gt_pos.shape[1]
    N_pre = pre_pos.shape[1]
    gt2 = (gt_pos**2).sum(0)
    gt2 = gt2[np.newaxis,:]
    pre2 = (pre_pos**2).sum(0)
    pre2 = pre2[np.newaxis,:]

    X2 = np.kron(gt2.T,np.ones([1,N_pre]))
    Y2 = np.kron(pre2,np.ones([N_gt,1]))
    _2XY = 2*np.dot(gt_pos.T,pre_pos)
    dis_mat = X2 + Y2 - _2XY

    return dis_mat

def location_eval(outputs_density, dot_labels):

    TP_seq = []
    FP_seq = []
    TN_seq = []
    dis_seq = []
    count_pre = []
    count_gt = []

    batchsize = outputs_density.shape[0]
    for i in range(batchsize):
        density = outputs_density[i,:,:,:].squeeze().cpu().numpy()
        dot_label = dot_labels[i,:,:,:].squeeze().cpu().numpy()

        count_pre.append(density.sum())
        count_gt.append(dot_label.sum())

        pre_pos = np.array(location(density))             #N*2
        gt_location = np.where(dot_label==1)
        gt_pos = np.vstack((gt_location[1],gt_location[0])).T   #N*2

        ori_pre_pos = copy.deepcopy(pre_pos)

        if min(pre_pos.shape) == 0:
            TP_seq.append(0)
            FP_seq.append(0)
            TN_seq.append(gt_pos.shape[0])
            continue
        if min(gt_pos.shape) == 0:
            TP_seq.append(0)
            FP_seq.append(pre_pos.shape[0])
            TN_seq.append(0)
            continue

        all_dis_mat = np.sqrt(distance_sq(pre_pos.T,gt_pos.T))
        dis_seq.extend(all_dis_mat.min(1))

        TP = 0
        for i in range(gt_pos.shape[0]):
            gt_loc = np.array([gt_pos[i,:]])
            if pre_pos.shape[0] == 0:
                continue
            dis_mat = np.sqrt(distance_sq(gt_loc.T,pre_pos.T))
            
            if dis_mat.min() < 6:
                TP += 1
                idex = np.where(dis_mat == dis_mat.min())
                pre_pos =  np.delete(pre_pos,idex[1],0)
                # dis_seq.append(dis_mat.min())
        

        density = density/max([density.max(),0.0001])*255
        density = np.array(density,dtype = np.uint8)

        TP_seq.append(TP)
        TN = gt_pos.shape[0] - TP
        TN_seq.append(TN)
        FP = ori_pre_pos.shape[0] - TP
        FP_seq.append(FP)


    count_pre = np.array(count_pre)
    count_gt = np.array(count_gt)
    
    #me = np.median(dis_seq)#中位数
    #q1 = np.percentile(dis_seq,25)#25%分位数
    #q3 = np.percentile(dis_seq,75)#25%分位数
    # print('me: %.4f, q1: %.4f, q3: %.4f'%(me,q1,q3))

    mae = (abs(count_pre-count_gt)).mean()
    mse = np.sqrt(((count_pre-count_gt)**2).mean())

    # print('Average number of cells: %.2f'%(count_gt.mean()))
    # print('mae: %.2f and mse: %.2f'%(mae,mse))

    total_tp = np.array(TP_seq).sum()
    total_tn = np.array(TN_seq).sum()
    total_fp = np.array(FP_seq).sum()
    total_p = total_tp + total_fp
    if total_p == 0:
        total_p += 0.01
    total_precision  = total_tp / total_p
    total_recall = total_tp / (total_tp + total_tn)
    
    to = total_precision + total_recall
    if to == 0:
        to += 0.01 
    F1 = 2*total_precision*total_recall/to
    return F1, mae



