import glob
import cv2
from numpy.core.numeric import NaN
import numpy as np 
import numpy.matlib
import os
import re
import copy
from pyheatmap.heatmap import HeatMap
import torch as t
from hungarian import Hungarian
import torch.nn.functional as F


def count_data(d, patch_size, step_size = None):
    
    if step_size is None:
        step_size = patch_size
    else:
        d = F.pad(d,[patch_size//2,patch_size//2,patch_size//2,patch_size//2])

    avg_pool = t.nn.AvgPool2d(patch_size,step_size)

    return patch_size*patch_size*avg_pool(d)

def circle_visualize(img,density,counting, r_thd):

    result = []
    max_value = []
    proportion = []
    counting_num = int(round(counting))
    pad_zeros = 3
    # density_tensor = t.from_numpy(density).unsqueeze(0).unsqueeze(0).float()
    # density_tensor_pad = F.pad(density_tensor,(pad_zeros,pad_zeros,pad_zeros,pad_zeros))

    # avg_pool_sg = t.nn.AvgPool2d(7,1)
    # density_pool = 7*7*avg_pool_sg(density_tensor_pad).squeeze().numpy()

    count = 0
    for i in range(int(counting_num)):
    # while True:
    #     if density_pool.max() < 0.2:
    #         break
        
        count += 1
        index = np.where(density == density.max())
        max_v = density.max()
        max_value.append(max_v)
        # if len(index[0])>1:
        #     index = (index[0][0],index[1][0])
        result.append([index[1][0],index[0][0]])

        img_height,img_width = img.shape[0],img.shape[1]
        del_index = [index[1][0],index[0][0]]  #(row,col)
        x1 = max(0, del_index[0] - r_thd)
        x2 = min(del_index[0] + r_thd + 1, img_width-1)
        y1 = max(0, del_index[1] - r_thd)
        y2 = min(del_index[1] + r_thd + 1, img_height-1)

        square_kernel = density[y1:y2,x1:x2]
        max_v_test = np.max(square_kernel)
        sum_value = np.sum(square_kernel)
        if sum_value == 0:
            sum_value = max_v
            if max_v == 0:
                sum_value = 0.1
        prop = max_v/sum_value

        proportion.append(prop)
        # cv2.rectangle(density,(x1,y1), (x2, y2), 0, -1)


        ##############!!!!!!!!!修改r!!!!!!!!########
        r = 4
        cv2.circle(density,(index[1][0],index[0][0]),r_thd,0,-1)
 
        # density_tensor = t.from_numpy(density).unsqueeze(0).unsqueeze(0).float()
        # density_tensor_pad = F.pad(density_tensor,(pad_zeros,pad_zeros,pad_zeros,pad_zeros))

        # avg_pool_sg = t.nn.AvgPool2d(7,1)
        # density_pool = 7*7*avg_pool_sg(density_tensor_pad).squeeze().numpy()

        cv2.circle(img,(index[1][0],index[0][0]),3,(10,10,250),-1)
    
    print('count: %.2f'%count)
    return img,result, max_value, proportion

def draw_circles(img, centers, radius, color, transparent = True):
    
    mask = np.zeros(img.shape,np.uint8)
    if transparent is not True:
        mask = img

    cv2.circle(mask,(int(centers[0]),int(centers[1])),radius,color,-1)
    
    return cv2.addWeighted(img, 1.0, mask, 0.5, 0)

def distance_sq(gt_pos,pre_pos):

    # gt_pos  2*M  
    # pre_pos 2*N
    # output  M*N

    N_gt = gt_pos.shape[1]
    N_pre = pre_pos.shape[1]
    gt2 = (gt_pos**2).sum(0)
    gt2 = gt2[np.newaxis,:]
    pre2 = (pre_pos**2).sum(0)
    pre2 = pre2[np.newaxis,:]

    X2 = np.kron(gt2.T,np.ones([1,N_pre]))
    Y2 = np.kron(pre2,np.ones([N_gt,1]))
    _2XY = 2*np.dot(gt_pos.T,pre_pos)
    dis_mat = X2 + Y2 - _2XY

    return dis_mat

if __name__ == "__main__":
    root = '../data/data_proc/part_B/'
    # root = '../data/data_proc/honeybee/'
    # root = '../data/data_proc/MBM_data/'
    # root = '../data/data_proc/colorectal_adenocarcinomas_old/'
    # root = '../data/data_proc/fish/'
    # root = '../data/data_proc/fly/'
    dataset = 'test'
    img_dir = root + dataset + '/imgs/imgs_2/'
    img_file = ['2']
    # img_size = [600, 600]
    # img_size = [500, 500]
    # img_size = [410, 300]
    # img_size = [72, 648]
    # img_size = [480, 640]
    img_size = [384, 512]
    
    label = 2
    test_file = img_file[0]

    r_thd = 5


    # img_list = glob.glob(img_dir + test_file + '/*.bmp')
    label_list = glob.glob(root + dataset + '/labels/*.txt')

    result_root = root +  '/result/label_50_p_0.1_kernel_11_r_6_bs_4-8-0.00005/100-1_prot/'
    # result_root = root +  '/result/label_100_1/'

    img_list=[]
    with open(result_root+'img_name.txt','r') as f:
        for line in f:
            img_list.append(img_dir  + '/' + line.strip('\n'))

    model = 'bmm'
    net_output = np.loadtxt(result_root + 'visual_' + model + '_' + dataset + '.txt')

    save_dir = result_root + '/' + model + '/'

    if False == os.path.exists(save_dir):
        os.makedirs(save_dir)

    start_pos = 0
   
    count = 1
    count_gt = []

    all_max_value = []
    all_proportion = []

    for _img_add in img_list:

        # if count>

        img_name = _img_add.split('/')[-1]

        # if img_name != 'img85.bmp':
        #     continue

        img = cv2.imread(_img_add)

        label = np.loadtxt(root + dataset + '/labels/'+img_name.split('.')[0]+'.txt')
        
        
        label_count = label.shape[0]
        count_gt.append(label_count)

        if len(img.shape) == 1:
            img = cv2.cvtColor(img,cv2.COLOR_GRAY2BGR)
        density_fore = net_output[start_pos+count][:]

        # a = (density > 0).sum()
        counting = density_fore.sum()#output_count #

        # print('the minimum value is: %.2f'%((-1*np.sort(-1*density))[int(counting)-1]))

        print(f'%d. {img_name}: max: %.4f, counting: %.2f, gt: %d'%(count,density_fore.max(),counting,label_count))
        # density[density>255] = 255
        density = density_fore.reshape(img_size[0],img_size[1])

        copy_img = copy.deepcopy(img)

        gt_result = []
        if len(label.shape) ==1:
            index = (min(int(label[0]+0.5),copy_img.shape[1]-1),min(int(label[1]+0.5),img.shape[0]-1))
        else:
            for i in range(len(label)):
                index = (min(int(label[i][0]+0.5),copy_img.shape[1]-1),min(int(label[i][1]+0.5),copy_img.shape[0]-1))
                gt_result.append([index[0],index[1]])
                # copy_img = draw_circles(copy_img,index,6,(255,0,0))
                # copy_img = draw_circles(copy_img, index, 6, (0,160,250), transparent = True)
                cv2.circle(copy_img,index,int(r_thd+1.5),(0,210,210),2)

        copy_density = copy.deepcopy(density)
        circle_img, pre_result, max_value, proportion = circle_visualize(copy_img,copy_density,counting, r_thd)

        all_max_value.append(max_value)
        all_proportion.append(proportion)

        count = count+1

        gt_pos = np.array(gt_result)
        pre_pos = np.array(pre_result)
        np.savetxt(save_dir + img_name.split('.j')[0]+ '_predicted.txt', pre_pos, fmt='%.2f')

        density = density/max([density.max(),0.0001])*255
        
        density = np.array(density,dtype = np.uint8)

        hm = cv2.applyColorMap(density,cv2.COLORMAP_JET)
        # cv2.imshow('hit_img',hm)
        # cv2.waitKey()

        density = cv2.cvtColor(density,cv2.COLOR_GRAY2BGR)
        # save_img = np.hstack((img,hm))
        save_img = np.hstack((hm,circle_img))
        # save_img = cv2.resize(save_img, ())

        # if img_name == 'beeType1_080.jpg':
        cv2.namedWindow('img_result',1)
        # cv2.imshow('img_result',save_img)
        # cv2.moveWindow('img_result',200,100)
        cv2.waitKey(1)
        
        # cv2.destroyAllWindows()
        save_name = save_dir+img_name.split('.j')[0]+ '-%.2f'%(counting)+'.bmp'
        cv2.imwrite(save_name,save_img)

    num = 0
    sum_v = 0
    sum_p = 0
    for i in range(len(all_max_value)):
        num = num + len(all_max_value[i])
        sum_v = sum_v + sum(all_max_value[i])
        sum_p = sum_p + sum(all_proportion[i])
    
    mean_v = sum_v/num
    mean_p = sum_p/num

    print('mean_v: %.4f, mean_p: %.4f'%(mean_v,mean_p))