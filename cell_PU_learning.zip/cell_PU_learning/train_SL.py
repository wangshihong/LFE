import torch as t
import torchvision as tv
import torchvision.transforms as transforms
import torch.nn.functional as F
import torch.backends.cudnn as cudnn
import matplotlib as mpl
# mpl.use('TkAgg')
import matplotlib.pyplot as plt
from datetime import datetime
import numpy as np
import random
import time
import os
import sys
import cv2
import shutil

import _init_path
import network
import lossfunc
from utils import Logger, location_eval
import dataset
# import load_data
# from circuit_breaker import circuit_breaker

# -----------------------
rand_seed = 64678  
if rand_seed is not None:
    os.environ['PYTHONHASHSEED'] = str(rand_seed)
    np.random.seed(rand_seed)
    t.manual_seed(rand_seed)
    t.cuda.manual_seed(rand_seed)
    t.cuda.manual_seed_all(rand_seed)
    random.seed(rand_seed)
    t.backends.cudnn.deterministic = True

# set environment
os.environ["CUDA_VISIBLE_DEVICES"] = '0,1,2,3,4,5'
device = t.device("cuda:0" if t.cuda.is_available() else "cpu")
device_ids = [0,1,2,3,4,5]


best_F1 = 0

def main():

    # data path
    img_dir = '../data/data_proc/colorectal_adenocarcinomas/'
    #img_dir = '../data/data_proc/MBM_data/'
    train_img_dir = img_dir + 'train/imgs/'
    train_label_dir = img_dir + 'train/labels/'
    val_img_dir = img_dir + 'validate/imgs/'
    val_label_dir = img_dir + 'validate/labels/'
    test_img_dir = img_dir + 'test/imgs/'
    test_label_dir = img_dir + 'test/labels/'

    
    #transform_train = transforms.Compose([
     #   dataset.RandomTransform(),
      #  dataset.ToTensor()
    #])
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
    ])

    
    kernel_size = 7
    epochs = 1024

    # split dataset to train and validate
    train_dataset = dataset.imgDataset(train_img_dir, train_label_dir, kernel_size, transform, train = True)

    val_dataset = dataset.imgDataset(val_img_dir, val_label_dir, kernel_size, transform,train = False )
    test_dataset = dataset.imgDataset(test_img_dir, test_label_dir, kernel_size, transform, train = False)
    

    train_loader = t.utils.data.DataLoader(train_dataset,
                                        batch_size = 16,pin_memory = False,
                                        shuffle = True,num_workers = 16)
    val_loader = t.utils.data.DataLoader(val_dataset,
                                        batch_size = 16,pin_memory = False,
                                        shuffle = False,num_workers = 16)
    test_loader = t.utils.data.DataLoader(test_dataset,
                                        batch_size = 16,pin_memory = False,
                                        shuffle = False,num_workers = 16)

    print('Numbers of samples in training dataset is: %d'%(len(train_dataset)))
    print('Numbers of samples in validation dataset is: %d'%(len(val_dataset)))
    print('Numbers of samples in test dataset is: %d'%(len(test_dataset)))


    checkpoint = False
    use_pseudolabel = False 
    update_lab = False
    train_net = 'LIRNet'

    # model initialization
    if train_net == 'LIRNet':
        model = network.LIRNet()
        network.weights_normal_init(model)

    model = t.nn.DataParallel(model,device_ids = device_ids)

    if checkpoint == True: # continue training

        save_add = './save_model/' + train_net + '/' + 'siamese_deconv_enh_relu_b16_g100_g20_10e' # checkpoint file-name
        offset = 10  # model number+2
        learning_rate = 0.0001  # learning rate

        model_dir = save_add + '/' + train_net + '-epoch_' + str(offset-2) + '.pt'
        model.load_state_dict(t.load(model_dir)) #checkpoint
  
        if use_pseudolabel:
            save_label_dir = img_dir + 'train/psedolabels_100_enh_100e/'
            if False == os.path.exists(save_label_dir):
                os.makedirs(save_label_dir)
            if update_lab:
                update_label(train_img_dir, train_label_dir, save_label_dir, model, device, patch_size = 20, margin = 0.2)
                sys.exit()

            train_label_dir = save_label_dir
    else:  # retraining
        # save address
        save_add = './save_model/' + train_net + '/' + datetime.now().strftime("%Y%m%d_%H%M%S")
        offset = 0
        learning_rate = 0.0001
        while False == os.path.exists(save_add):
            os.makedirs(save_add)

    model.to(device)
    model.train() 
    print(model)

    cudnn.benchmark = True
    print('    Total params: %.2fM' % (sum(p.numel() for p in model.parameters())/1000000.0))

    train_criterion = lossfunc.L2Loss(1.0)
    val_criterion = lossfunc.L2Loss(1.0)
    optimizer = t.optim.Adam(model.parameters(), lr=learning_rate)

    # learning rate scheduler
    scheduler = t.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min',factor=0.1,patience=100,verbose=True,)
    
    logger = Logger(os.path.join('result', 'log.txt'), title='cell_pulearning')
    logger.set_names(['Train Loss', 'Valid Loss', 'Valid Count','Valid MAE', 'Valid MSE', 'Test Loss', 'Test Count', 'Test MAE', 'Test MSE'])

    best_MAE = 1e20

    for epoch in range(epochs):

        print('\nEpoch: [%d | %d] LR: %f'%(epoch+1, epochs, optimizer.param_groups[0]['lr']))
        train_loss = train(train_loader, model, optimizer, train_criterion, kernel_size)
        
        save_flag = False
        if epoch % 5 == 0: 
            save_name = save_add + '/' + train_net + '-epoch_' + str(epoch + offset) + '.pt'
            print(save_name)
            t.save(model.state_dict(),save_name)
            save_flag = True
        
        val_loss, val_mae, val_mse, val_ct_mean = validate_CE(val_loader, model, val_criterion, kernel_size, len(val_dataset), save_density = save_flag, epoch = epoch)
        test_loss, test_mae, test_mse, test_ct_mean = validate_CE(test_loader, model, val_criterion, kernel_size, len(test_dataset))
       
        scheduler.step(val_loss)
        # append logger file
        logger.append([train_loss, val_loss, val_ct_mean, val_mae, val_mse, test_loss, test_ct_mean, test_mae, test_mse])
        print('\n')
        print('val_loss: %.5f, val_count: %.2f, val_mae: %.2f, val_mse: %.2f'%(val_loss,val_ct_mean, val_mae,val_mse))
        print('test_loss: %.5f, test_count: %.2f, test_mae: %.2f, test_mse: %.2f'%(test_loss,test_ct_mean,test_mae,test_mse))
        
        #save model
        is_best = val_mae < best_MAE
        best_MAE = min(val_mae, best_MAE)
        save_checkpoint({
                'epoch': epoch + 1,
                'state_dict': model.state_dict(),
                'MAE': val_mae,
                'best_MAE': best_MAE,
                'optimizer' : optimizer.state_dict(),
            }, is_best)
    
    print('Best MAE in val_dataset:')
    print(best_MAE)


    
    
# train section
def train(train_loader, model, optimizer, train_criterion, kernel_size):

    t_start = time.time()
    running_loss = 0.0
    iterations = 0

    model.train()
    for i, data in enumerate(train_loader):

        inputs,dot_labels,mask_labels = data[0].to(device),data[1].to(device),data[2].to(device)

        # with t.no_grad():
        #     outputs = model(inputs)

        outputs_density = model(inputs)
        loss = train_criterion(outputs_density,dot_labels.float(),mask_labels.float(),kernel_size)

        running_loss += loss.item()

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        iterations = i
        print('[%d | 9] loss: %.5f, max_value: %.5f'%(i+1,loss, outputs_density.max().cpu().detach().numpy()))
    
    t_end = time.time()
    print('\n')
    print('loss: %.5f | Time per epoch: %.2f'%(running_loss/(iterations+1),t_end-t_start))
    print('\n')
    return running_loss/(iterations+1)


def validate_regression(val_loader, model, val_criterion, kernel_size, num_data, save_density = False, epoch = 0):
    
    model.eval()
    running_loss = 0.0
    ae = 0
    se = 0
    t_start = time.time()
    with t.no_grad():
        for i, data in enumerate(val_loader):
    
            inputs,dot_labels,mask_labels = data[0].to(device),data[1].to(device),data[2].to(device)

            outputs_density = model(inputs)

            if save_density:
                save_visualization(outputs_density[0,0,:,:].squeeze().cpu().numpy(), epoch)

            gt = t.sum(dot_labels,[2,3])
            ae += t.abs(t.sum(outputs_density,[2,3])-gt).sum()
            se += ((t.sum(outputs_density,[2,3])-gt)*(t.sum(outputs_density,[2,3])-gt)).sum()

            loss = val_criterion(outputs_density,dot_labels.float(),mask_labels.float(),kernel_size)
            running_loss += loss.item()
        
        val_loss = running_loss/num_data
        val_mae = ae/num_data
        val_mse = t.sqrt(se/num_data)

    return val_loss, val_mae, val_mse

def validate_CE(val_loader, model, val_criterion, kernel_size, num_data, save_density = False, epoch = 0):
    
    model.eval()
    running_loss = 0.0
    ae = 0
    se = 0
    ct_pre = 0
    t_start = time.time()
    with t.no_grad():
        for i, data in enumerate(val_loader):
    
            inputs,dot_labels,mask_labels = data[0].to(device),data[1].to(device),data[2].to(device)

            outputs_density = model(inputs)

            if save_density:
                save_visualization(outputs_density[0,0,:,:].squeeze().cpu().numpy(), epoch)
                print('test count: %.2f'%(outputs_density[0,0,:,:].sum()))
            gt = t.sum(dot_labels,[2,3])
            output_p = t.tanh(lossfunc.count_data(outputs_density,kernel_size,1))
            output_count = t.sum(output_p,[2,3])/(kernel_size*kernel_size)
            ae += t.abs(output_count-gt).sum()
            se += ((output_count-gt)*(output_count-gt)).sum()
            ct_pre += output_count.sum()

            loss = val_criterion(outputs_density,dot_labels.float(),mask_labels.float(),kernel_size)
            running_loss += loss.item()
        
        val_loss = running_loss/num_data
        val_mae = ae/num_data
        val_mse = t.sqrt(se/num_data)
        ct_mean = ct_pre/num_data

    return val_loss, val_mae, val_mse, ct_mean


def save_visualization(density, epoch):
    density_img = density/max([density.max(),0.0001])*255
    density_img = np.array(density_img,dtype = np.uint8)
    cv2.imwrite('./result/density_imgs/density_' + str(epoch) + '.bmp', density_img)



def save_checkpoint(state, is_best, checkpoint='result', filename='checkpoint.pth.tar'):
    filepath = os.path.join(checkpoint, filename)
    t.save(state, filepath)
    if is_best:
        shutil.copyfile(filepath, os.path.join(checkpoint, 'model_best.pth.tar'))

if __name__ == '__main__':
    main()
