import glob
import cv2
import numpy as np 
import numpy.matlib
import os
import re
import copy
from pyheatmap.heatmap import HeatMap
import torch as t
from hungarian import Hungarian
import torch.nn.functional as F


def count_data(d, patch_size, step_size = None):
    
    if step_size is None:
        step_size = patch_size
    else:
        d = F.pad(d,[patch_size//2,patch_size//2,patch_size//2,patch_size//2])

    avg_pool = t.nn.AvgPool2d(patch_size,step_size)

    return patch_size*patch_size*avg_pool(d)

def circle_visualize(img,density,counting, r_thd):

    result = []
    counting_num = int(round(counting))
    pad_zeros = 3
    # density_tensor = t.from_numpy(density).unsqueeze(0).unsqueeze(0).float()
    # density_tensor_pad = F.pad(density_tensor,(pad_zeros,pad_zeros,pad_zeros,pad_zeros))

    # avg_pool_sg = t.nn.AvgPool2d(7,1)
    # density_pool = 7*7*avg_pool_sg(density_tensor_pad).squeeze().numpy()

    count = 0
    for i in range(int(counting_num)):
    # while True:
    #     if density_pool.max() < 0.2:
    #         break
        
        count += 1
        index = np.where(density == density.max())
        # if len(index[0])>1:
        #     index = (index[0][0],index[1][0])
        result.append([index[1][0],index[0][0]])

        # r = 4
        # img_height,img_width = img.shape[0],img.shape[1]
        # del_index = [index[1][0],index[0][0]]  #(row,col)
        # x1 = max(0, del_index[0] - r)
        # x2 = min(del_index[0] + r + 1, img_width-1)
        # y1 = max(0, del_index[1] - r)
        # y2 = min(del_index[1] + r + 1, img_height-1)
        # cv2.rectangle(density,(x1,y1), (x2, y2), 0, -1)

        ##############!!!!!!!!!修改r!!!!!!!!########
        r = 6
        cv2.circle(density,(index[1][0],index[0][0]),r,0,-1)
 
        # density_tensor = t.from_numpy(density).unsqueeze(0).unsqueeze(0).float()
        # density_tensor_pad = F.pad(density_tensor,(pad_zeros,pad_zeros,pad_zeros,pad_zeros))

        # avg_pool_sg = t.nn.AvgPool2d(7,1)
        # density_pool = 7*7*avg_pool_sg(density_tensor_pad).squeeze().numpy()

        cv2.circle(img,(index[1][0],index[0][0]),3,(10,10,250),-1)
    
    print('count: %.2f'%count)
    return img,result

def draw_circles(img, centers, radius, color, transparent = True):
    
    mask = np.zeros(img.shape,np.uint8)
    if transparent is not True:
        mask = img

    cv2.circle(mask,(int(centers[0]),int(centers[1])),radius,color,-1)
    
    return cv2.addWeighted(img, 1.0, mask, 0.5, 0)

def distance_sq(gt_pos,pre_pos):

    # gt_pos  2*M  
    # pre_pos 2*N
    # output  M*N

    N_gt = gt_pos.shape[1]
    N_pre = pre_pos.shape[1]
    gt2 = (gt_pos**2).sum(0)
    gt2 = gt2[np.newaxis,:]
    pre2 = (pre_pos**2).sum(0)
    pre2 = pre2[np.newaxis,:]

    X2 = np.kron(gt2.T,np.ones([1,N_pre]))
    Y2 = np.kron(pre2,np.ones([N_gt,1]))
    _2XY = 2*np.dot(gt_pos.T,pre_pos)
    dis_mat = X2 + Y2 - _2XY

    return dis_mat

if __name__ == "__main__":
    root = '../data/data_proc/part_B/'
    # root = '../data/data_proc/honeybee/'
    # root = '../data/data_proc/MBM_data/'
    # root = '../data/data_proc/honeybee/'
    # root = '../data/data_proc/fish/'
    # root = '../data/data_proc/fly/'
    dataset = 'test'
    img_dir = root + dataset + '/imgs/imgs_2/'
    img_file = ['2']
    # img_size = [500, 500]
    # img_size = [410, 300]
    # img_size = [72, 648]
    img_size = [384, 512]
    
    label = 2
    test_file = img_file[0]

    r_thd = 6


    # img = np.ones((500,500))*255
    # img = np.array(img,dtype = np.uint8)
    # cv2.rectangle(img, (100,200), (300, 300),0, -1)
    # cv2.imshow('img',img)
    # cv2.waitKey()



    # img_list = glob.glob(img_dir + test_file + '/*.bmp')
    label_list = glob.glob(root + dataset + '/labels/*.txt')

    result_root = root +  '/result/label_50_p_0.1_kernel_11_r_6_bs_4-8-0.00005/'

    img_list=[]
    with open(result_root+'img_name.txt','r') as f:
        for line in f:
            img_list.append(img_dir  + '/' + line.strip('\n'))

    model = 'bmm'
    net_output = np.loadtxt(result_root + 'visual_' + model + '_' + dataset + '.txt')

    save_dir = result_root + '/' + model + '/'

    if False == os.path.exists(save_dir):
        os.makedirs(save_dir)

    start_pos = 0
   
    count = 1
    count_pre = []
    count_gt = []

    TP_seq = []
    FP_seq = []
    TN_seq = []
    dis_seq = []
    for _img_add in img_list:

        # if count>

        img_name = _img_add.split('/')[-1]

        # if img_name != 'img85.bmp':
        #     continue

        img = cv2.imread(_img_add)

        label = np.loadtxt(root + dataset + '/labels/'+img_name.split('.')[0]+'.txt')
        
        
        label_count = label.shape[0]
        count_gt.append(label_count)

        if len(img.shape) == 1:
            img = cv2.cvtColor(img,cv2.COLOR_GRAY2BGR)
        density_fore = net_output[start_pos+count][:]


        # double_density = t.zeros(1,1,500,500)
        # double_density[:,0,:,:] = t.from_numpy(density_fore.reshape(500,500))
        # output_seg = t.tanh(count_data(double_density,7,1)).squeeze().numpy()
        # output_count = output_seg.sum()/(7*7)

        # output_seg[output_seg >= 0.5] = 1
        # output_seg[output_seg < 0.5] = 0




        # a = (density > 0).sum()
        counting = density_fore.sum()#output_count #
        count_pre.append(counting)

        # print('the minimum value is: %.2f'%((-1*np.sort(-1*density))[int(counting)-1]))

        print(f'%d. {img_name}: max: %.4f, counting: %.2f, gt: %d'%(count,density_fore.max(),counting,label_count))
        # density[density>255] = 255
        density = density_fore.reshape(img_size[0],img_size[1])

        # gt_generator = gtGenerator(density)
        # pseudo_attention = cv2.resize(gt_generator.generate_pseudo_attention(),(500//2,500//2))

        # pseudo_attention = pseudo_attention/max([pseudo_attention.max(),0.000001])*255
        # pseudo_attention = np.array(pseudo_attention,dtype = np.uint8)

        # hm = cv2.applyColorMap(pseudo_attention,cv2.COLORMAP_JET)
        # cv2.imshow('pseudo_attention',hm)
        # cv2.waitKey()

        label_img_tensor = t.from_numpy(density).unsqueeze(0).unsqueeze(0).float()

        lg_size = 5
        avg_pool_lg = t.nn.AvgPool2d(lg_size,1)
        label_lg = lg_size*lg_size*avg_pool_lg(label_img_tensor).squeeze().numpy()
        # print('number of nonzeros: %d'%((label_lg>1).sum()))
        # density = cv2.resize(density,(500,500))

        copy_img = copy.deepcopy(img)

        gt_result = []
        if len(label.shape) ==1:
            index = (min(int(label[0]+0.5),copy_img.shape[1]-1),min(int(label[1]+0.5),img.shape[0]-1))
        else:
            for i in range(len(label)):
                index = (min(int(label[i][0]+0.5),copy_img.shape[1]-1),min(int(label[i][1]+0.5),copy_img.shape[0]-1))
                gt_result.append([index[0],index[1]])
                # copy_img = draw_circles(copy_img,index,6,(255,0,0))
                # copy_img = draw_circles(copy_img, index, 6, (0,160,250), transparent = True)
                cv2.circle(copy_img,index,int(r_thd+1.5),(0,210,210),2)

        copy_density = copy.deepcopy(density)
        circle_img, pre_result = circle_visualize(copy_img,copy_density,counting, r_thd)


        gt_pos = np.array(gt_result)
        pre_pos = np.array(pre_result)

        ori_pre_pos = copy.deepcopy(pre_pos)

        if min(pre_pos.shape) == 0:
            TP_seq.append(0)
            FP_seq.append(0)
            TN_seq.append(gt_pos.shape[0])
            count = count+1
            continue
        if min(gt_pos.shape) == 0:
            TP_seq.append(0)
            FP_seq.append(pre_pos.shape[0])
            TN_seq.append(0)
            count = count+1
            continue

        all_dis_mat = np.sqrt(distance_sq(pre_pos.T,gt_pos.T))
        dis_seq.extend(all_dis_mat.min(1))

        TP = 0
        for i in range(gt_pos.shape[0]):
            gt_loc = np.array([gt_pos[i,:]])
            if pre_pos.shape[0] == 0:
                continue
            dis_mat = np.sqrt(distance_sq(gt_loc.T,pre_pos.T))
            
            if dis_mat.min() < r_thd:
                TP += 1
                idex = np.where(dis_mat == dis_mat.min())
                pre_pos =  np.delete(pre_pos,idex[1],0)
                # dis_seq.append(dis_mat.min())
        

        density = density/max([density.max(),0.0001])*255
        
        density = np.array(density,dtype = np.uint8)

        TP_seq.append(TP)
        TN = gt_pos.shape[0] - TP
        TN_seq.append(TN)
        FP = ori_pre_pos.shape[0] - TP
        FP_seq.append(FP)

        prec = TP/(TP+FP)
        reca = TP/(TP+TN)
        print('precison: %.3f, recall: %.3f'%(prec,reca))

        # output_seg = output_seg/max([output_seg.max(),0.0001])*255
        # output_seg = np.array(output_seg,dtype = np.uint8)

        hm = cv2.applyColorMap(density,cv2.COLORMAP_JET)
        # cv2.imshow('hit_img',hm)
        # cv2.waitKey()

        count = count+1
        density = cv2.cvtColor(density,cv2.COLOR_GRAY2BGR)
        # save_img = np.hstack((img,hm))
        save_img = np.hstack((hm,circle_img))
        # save_img = cv2.resize(save_img, ())

        # if img_name == 'beeType1_080.jpg':
        cv2.namedWindow('img_result',1)
        cv2.imshow('img_result',save_img)
        # cv2.moveWindow('img_result',200,100)
        cv2.waitKey(1)
        
        # cv2.destroyAllWindows()
        save_name = save_dir+img_name.split('.j')[0]+ '-%.2f'%(counting)+'.bmp'
        cv2.imwrite(save_name,save_img)
        # cv2.waitKey(1)
    
    count_pre = np.array(count_pre)
    count_gt = np.array(count_gt)
    
    me = np.median(dis_seq)#中位数
    q1 = np.percentile(dis_seq,25)#25%分位数
    q3 = np.percentile(dis_seq,75)#25%分位数
    print('me: %.4f, q1: %.4f, q3: %.4f'%(me,q1,q3))

    gt_sum = count_gt.sum()
    mae = (abs(count_pre-count_gt)).mean()
    mse = np.sqrt(((count_pre-count_gt)**2).mean())

    print('Average number of cells: %.2f'%(count_gt.mean()))
    print('mae: %.2f and mse: %.2f'%(mae,mse))

    total_tp = np.array(TP_seq).sum()
    total_tn = np.array(TN_seq).sum()
    total_fp = np.array(FP_seq).sum()
    total_precision  = total_tp / (total_tp + total_fp)
    total_recall = total_tp / (total_tp + total_tn)
    total_F1 = 2*total_precision*total_recall/(total_precision + total_recall)

    print('total precision: %.4f, total recall: %.4f, total_F1: %.4f'%(total_precision,total_recall,total_F1))

    print('average counting_pre: ', count_pre.mean())