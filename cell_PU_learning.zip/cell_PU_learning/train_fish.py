import torch as t
import torchvision as tv
import torchvision.transforms as transforms
import torch.backends.cudnn as cudnn
import matplotlib as mpl
# mpl.use('TkAgg')
import matplotlib.pyplot as plt
from datetime import datetime
import numpy as np
import random
import time
import os
import sys
import cv2
import shutil

import _init_path
import network
import lossfunc
from utils import dataset_split, Logger, update_labels, randTransform, reverseTransform, track_training_loss, compute_probabilities_batch, location_eval
import dataset
# from circuit_breaker import circuit_breaker

# -----------------------
rand_seed = random.randint(1,10000) #64678
print('rand_seed: %d'%(rand_seed)) 
if rand_seed is not None:
    os.environ['PYTHONHASHSEED'] = str(rand_seed)
    np.random.seed(rand_seed)
    t.manual_seed(rand_seed)
    t.cuda.manual_seed(rand_seed)
    t.cuda.manual_seed_all(rand_seed)
    t.backends.cudnn.deterministic = True

# set environment
os.environ["CUDA_VISIBLE_DEVICES"] = '2,3,4,5'
device = t.device("cuda:0" if t.cuda.is_available() else "cpu")
device_ids = [0,1,2,3]


best_F1 = 0

def main():

    # split_num = [40,20,40]
    kernel_size = 13
    num_labels = 10
    pi_positive = 0.1

    r_thd = 8
    fixed_epochs = 20
    epochs_pu = 100
    epochs_bmm = 100
    
    checkpoint = False

    # data path
    #data_dir = '../data/data_proc/colorectal_adenocarcinomas/'
    #data_dir = '../data/data_proc/MBM_data/'
    data_dir = '../data/data_proc/fish/'
    
    #img_dir = '../data/data_proc/MBM_data/'
    # img_dir = data_dir + 'all/imgs/'
    # label_dir = data_dir + 'all/labels/'
    
    # if checkpoint is False:
    #     #dataset_split(img_dir,label_dir,split_num)
    #     print('Random split dataset!!!!!!!')

    train_img_dir = data_dir + 'train/imgs/'
    train_label_dir = data_dir + '/train/labels/'
    val_img_dir = data_dir + 'validate/imgs/'
    val_label_dir = data_dir + 'validate/labels/'
    test_img_dir = data_dir + 'test/imgs/'
    test_label_dir = data_dir + 'test/labels/'


    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
    ])


    # split dataset to train and validate
    train_dataset = dataset.imgDataset(train_img_dir, train_label_dir, kernel_size, transform, train = True, train_num = num_labels, rand_seed = rand_seed, BMM = False)
    train_unlabel_dataset = dataset.imgDataset(train_img_dir, train_label_dir, kernel_size, transform, train = True, train_num = num_labels, rand_seed = rand_seed, BMM = False)
    train_BMM_dataset = dataset.imgDataset(train_img_dir, train_label_dir, kernel_size, transform, train = True, train_num = num_labels, rand_seed = rand_seed, BMM = True)

    val_dataset = dataset.imgDataset(val_img_dir, val_label_dir, kernel_size, transform,train = False )
    test_dataset = dataset.imgDataset(test_img_dir, test_label_dir, kernel_size, transform, train = False)
    

    train_loader = t.utils.data.DataLoader(train_dataset,
                                        batch_size = 8,pin_memory = False,
                                        shuffle = True,num_workers = 8)
    train_unlabel_loader = t.utils.data.DataLoader(train_unlabel_dataset,
                                        batch_size = 16,pin_memory = False,
                                        shuffle = True,num_workers = 16)
    train_BMM_loader = t.utils.data.DataLoader(train_BMM_dataset,
                                        batch_size = 16,pin_memory = False,
                                        shuffle = True,num_workers = 16)
    val_loader = t.utils.data.DataLoader(val_dataset,
                                        batch_size = 16,pin_memory = False,
                                        shuffle = False,num_workers = 16)
    test_loader = t.utils.data.DataLoader(test_dataset,
                                        batch_size = 16,pin_memory = False,
                                        shuffle = False,num_workers = 16)

    print('Numbers of samples in training dataset is: %d'%(len(train_dataset)))
    print('Numbers of samples in validation dataset is: %d'%(len(val_dataset)))
    print('Numbers of samples in test dataset is: %d'%(len(test_dataset)))


    train_net = 'LIRNet'

    # model initialization
    if train_net == 'LIRNet':
        model = network.LIRNet()
        network.weights_normal_init(model)

    model = t.nn.DataParallel(model,device_ids = device_ids)

    if checkpoint == True: # continue training

        save_add = './save_model/' + train_net + '/' + 'pu_test' # checkpoint file-name
        offset = 55  # model number+2
        learning_rate = 0.0001  # learning rate

        # model_dir = save_add + '/' + train_net + '-epoch_' + str(offset-5) + '.pt'
        model_dir = './best_model_pu.pt'
        model.load_state_dict(t.load(model_dir)) #checkpoint
  
    else:  # retraining
        # save address
        save_add = './save_model/' + train_net + '/' + datetime.now().strftime("%Y%m%d_%H%M%S")
        offset = 0
        learning_rate = 0.0001
        while False == os.path.exists(save_add):
            os.makedirs(save_add)

    model.to(device)
    model.train() 
    # print(model)

    cudnn.benchmark = True
    print('    Total params: %.2fM' % (sum(p.numel() for p in model.parameters())/1000000.0))

    train_criterion_PU = lossfunc.nnPULoss_L2tanh()
    val_criterion = lossfunc.L2tanhLoss(0.1)

    optimizer_pu = t.optim.Adam(model.parameters(), lr=learning_rate)

    # learning rate scheduler
    scheduler_pu = t.optim.lr_scheduler.ReduceLROnPlateau(optimizer_pu, mode='max',factor=0.1,patience=20,verbose=True,)
    #scheduler = t.optim.lr_scheduler.StepLR(optimizer, step_size = 100, gamma = 0.1, last_epoch=-1)   

    logger = Logger(os.path.join('result', 'log.txt'), title='cell_pulearning')
    logger.set_names(['Train Loss', 'Valid Loss', 'Valid Count','Valid MAE', 'Valid MSE', 'Valid F1', 'Test Loss', 'Test Count', 'Test MAE', 'Test MSE', 'Test F1'])

    best_F1_pu = 0

    # train pu-learning
    print('\n>>>>>>>>>>>>>>>>> Positive-unlabeled Training <<<<<<<<<<<<<<<<<\n')
    for epoch in range(epochs_pu):

        print('\nEpoch: [%d | %d] LR: %.9f'%(epoch+1, epochs_pu, optimizer_pu.param_groups[0]['lr']))

        train_loss = train_pu(train_loader, train_unlabel_loader, model, optimizer_pu, train_criterion_PU, kernel_size, pi_positive)

        save_flag = False
        if epoch % 10 == 0: 
            save_flag = True

        if epoch >= fixed_epochs:
            val_loss, val_ct_mean, val_mae, val_mse, val_F1 = validate_regression(val_loader, model, val_criterion, kernel_size, len(val_dataset), r_thd, save_density = save_flag, epoch = epoch)
            test_loss, test_ct_mean, test_mae, test_mse, test_F1 = validate_regression(test_loader, model, val_criterion, kernel_size, len(test_dataset), r_thd)
        
            scheduler_pu.step(val_F1)

            # append logger file
            print('\nrand_seed: %d'%(rand_seed))
            logger.append([train_loss, val_loss, val_ct_mean, val_mae, val_mse, val_F1, test_loss, test_ct_mean, test_mae, test_mse, test_F1])
            print('\n')
            print('val_loss: %.5f, val_count: %.2f, val_mae: %.2f, val_mse: %.2f, val_F1: %.4f'%(val_loss,val_ct_mean, val_mae,val_mse, val_F1))
            print('test_loss: %.5f, test_count: %.2f, test_mae: %.2f, test_mse: %.2f, test_F1: %.4f'%(test_loss,test_ct_mean,test_mae,test_mse,test_F1))
            
            #save model
            is_best = val_F1 > best_F1_pu
            best_F1_pu = max(val_F1, best_F1_pu)
            if is_best:
                save_name = 'best_model_pu.pt'
                print(save_name)
                t.save(model.state_dict(),save_name)


    # train LNL-learning
    train_criterion_BMM = lossfunc.L2tanhLoss_BMM(0.1)
    optimizer_bmm = t.optim.Adam(model.parameters(), lr=learning_rate*0.01)
    scheduler_bmm = t.optim.lr_scheduler.ReduceLROnPlateau(optimizer_bmm, mode='max',factor=0.1,patience=20,verbose=True,)

    model.load_state_dict(t.load('./best_model_pu.pt')) #checkpoint
    model.to(device)
    model.train()
    print('\nload best pu-model!!!!!!!!!!!!!!!!!!!!!!!!!!!\n')
    print('\n>>>>>>>>>>>>>>>>> PN-Training with BMM noise modeling <<<<<<<<<<<<<<<<<\n')

    best_F1_bmm = best_F1_pu
    
    bmm_model = bmm_model_maxLoss = bmm_model_minLoss = 0

    for epoch in range(epochs_bmm):

        print('\nEpoch: [%d | %d] LR: %.9f'%(epoch+1, epochs_bmm, optimizer_bmm.param_groups[0]['lr']))

        bmm_model, bmm_model_maxLoss, bmm_model_minLoss = track_training_loss(model, device, train_BMM_loader, kernel_size, epoch, bmm_model, bmm_model_maxLoss, bmm_model_minLoss)
        train_loss = train_bmm(train_loader, train_BMM_loader, model, optimizer_bmm, train_criterion_BMM, kernel_size, num_labels, pi_positive, bmm_model, bmm_model_maxLoss, bmm_model_minLoss)

        save_flag = False
        if epoch % 10 == 0: 
            save_flag = True

        val_loss, val_ct_mean, val_mae, val_mse, val_F1 = validate_regression(val_loader, model, val_criterion, kernel_size, len(val_dataset), r_thd, save_density = save_flag, epoch = epoch)
        test_loss, test_ct_mean, test_mae, test_mse, test_F1 = validate_regression(test_loader, model, val_criterion, kernel_size, len(test_dataset), r_thd)
       
        scheduler_bmm.step(val_F1)

        # append logger file
        print('\nrand_seed: %d'%(rand_seed))
        logger.append([train_loss, val_loss, val_ct_mean, val_mae, val_mse, val_F1, test_loss, test_ct_mean, test_mae, test_mse, test_F1])
        print('\n')
        print('val_loss: %.5f, val_count: %.2f, val_mae: %.2f, val_mse: %.2f, val_F1: %.4f'%(val_loss,val_ct_mean, val_mae,val_mse, val_F1))
        print('test_loss: %.5f, test_count: %.2f, test_mae: %.2f, test_mse: %.2f, test_F1: %.4f'%(test_loss,test_ct_mean,test_mae,test_mse,test_F1))
        
        #save model
        is_best = val_F1 > best_F1_bmm
        best_F1_bmm = max(val_F1, best_F1_bmm)
        if is_best:
            save_name = 'best_model_bmm.pt'
            print(save_name)
            t.save(model.state_dict(),save_name)

    # best pu-model eval
    model.load_state_dict(t.load('./best_model_pu.pt')) #checkpoint
    model.to(device)
    val_loss, val_ct_mean, val_mae, val_mse, val_F1 = validate_regression(val_loader, model, val_criterion, kernel_size, len(val_dataset), r_thd, save_density = save_flag, epoch = epoch)
    test_loss, test_ct_mean, test_mae, test_mse, test_F1 = validate_regression(test_loader, model, val_criterion, kernel_size, len(test_dataset), r_thd)
    print('\n')
    print('val_loss: %.5f, val_count: %.2f, val_mae: %.2f, val_mse: %.2f, val_F1: %.4f'%(val_loss,val_ct_mean, val_mae,val_mse, val_F1))
    print('test_loss: %.5f, test_count: %.2f, test_mae: %.2f, test_mse: %.2f, test_F1: %.4f'%(test_loss,test_ct_mean,test_mae,test_mse,test_F1))

    #best lnl-model eval
    model.load_state_dict(t.load('./best_model_bmm.pt')) #checkpoint
    model.to(device)
    val_loss, val_ct_mean, val_mae, val_mse, val_F1 = validate_regression(val_loader, model, val_criterion, kernel_size, len(val_dataset), r_thd, save_density = save_flag, epoch = epoch)
    test_loss, test_ct_mean, test_mae, test_mse, test_F1 = validate_regression(test_loader, model, val_criterion, kernel_size, len(test_dataset), r_thd)
    print('\n')
    print('val_loss: %.5f, val_count: %.2f, val_mae: %.2f, val_mse: %.2f, val_F1: %.4f'%(val_loss,val_ct_mean, val_mae,val_mse, val_F1))
    print('test_loss: %.5f, test_count: %.2f, test_mae: %.2f, test_mse: %.2f, test_F1: %.4f'%(test_loss,test_ct_mean,test_mae,test_mse,test_F1))


# train section
def train_pu(train_loader, train_unlabel_loader, model, optimizer, train_criterion_PU, kernel_size, pi_positive):

    t_start = time.time()
    running_loss = 0.0
    iterations = 0

    model.train()
    unlabel_train_iter = iter(train_unlabel_loader)
    for i, data in enumerate(train_loader):

        label_inputs_a,dot_labels_a,mask_labels_a = data[0].to(device),data[1].to(device),data[2].to(device)
        label_inputs_b, transform_mode = randTransform(label_inputs_a, device)
        dot_labels_b, _ = randTransform(dot_labels_a, device, transform_mode)
        mask_labels_b, _ = randTransform(mask_labels_a, device, transform_mode)

        label_inputs = t.cat((label_inputs_a, label_inputs_b))
        dot_labels = t.cat((dot_labels_a, dot_labels_b))
        mask_labels = t.cat((mask_labels_a, mask_labels_b))
        
        label_outputs_density = model(label_inputs)

        try:
            unlabel_inputs,_,_ = unlabel_train_iter.next()
        except:
            unlabel_train_iter = iter(train_unlabel_loader)
            unlabel_inputs,_,_ = unlabel_train_iter.next()

        unlabel_outputs_density = model(unlabel_inputs)


        # positive-unlabel learning
        loss, nn_flag = train_criterion_PU(label_outputs_density, unlabel_outputs_density, mask_labels.float(), kernel_size, pi_positive, device)
        # loss = train_criterion(label_outputs_density, mask_labels.float(), kernel_size)

        running_loss += loss.item()

        if nn_flag:
            print('nn_flag is True!!!!!!!!!!')
            loss = 0.2 * loss

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        iterations = i
        print('[%d | 9] loss: %.5f, max_value: %.5f'%(i+1,loss, label_outputs_density.max().cpu().detach().numpy()))
    
    t_end = time.time()
    print('\n')
    print('loss: %.5f | Time per epoch: %.2f'%(running_loss/(iterations+1),t_end-t_start))
    print('\n')
    return running_loss/(iterations+1)

# train section
def train_bmm(train_loader, train_BMM_loader, model, optimizer, train_criterion_BMM, kernel_size, num_labels, pi_positive, bmm_model, bmm_model_maxLoss, bmm_model_minLoss):

    t_start = time.time()
    running_loss = 0.0
    iterations = 0

    model.train()  
   
    for i, data in enumerate(train_BMM_loader):
        label_inputs,dot_labels,mask_labels = data[0].to(device),data[1].to(device),data[2].to(device)
        label_outputs_density = model(label_inputs)
        with t.no_grad():
            
            outputs_0 = model(label_inputs)
            label_inputs_1, transform_mode = randTransform(label_inputs, device)
            outputs_1 = model(label_inputs_1)
            outputs = (outputs_0 + reverseTransform(outputs_1, transform_mode, device)) / 2
            
            loss_prob_batch, label_negative_mask = compute_probabilities_batch(outputs, mask_labels, kernel_size, bmm_model, bmm_model_maxLoss, bmm_model_minLoss)
            loss_prob_batch = loss_prob_batch.to(device)
            label_negative_mask = label_negative_mask.to(device).mul(mask_labels)

            corrected_dot_labels, corrected_mask_labels = update_labels(outputs, dot_labels, mask_labels, loss_prob_batch, kernel_size, num_labels)
            corrected_dot_labels = corrected_dot_labels.detach().to(device)
            corrected_mask_labels = corrected_mask_labels.detach().to(device)
            #a = corrected_mask_labels.sum()    

        # #mixup
        # alpha = 0.75
        # l = np.random.beta(alpha, alpha)
        # l = max(l, 1-l)

        # idx = t.randperm(label_inputs.size(0))
        # input_a, input_b = label_inputs, label_inputs[idx]
        # mixed_input = l * input_a + (1 - l) * input_b

        # mixed_img = mixed_input[0,:,:,:].cpu().numpy()
        # mixed_img = mixed_img/max([mixed_img.max(),0.0001])*255
        # mixed_img = np.array(mixed_img,dtype = np.uint8)
        # mixed_img = cv2.merge([mixed_img[0,:,:],mixed_img[1,:,:],mixed_img[2,:,:]])
        # cv2.imwrite('mixed_img.bmp',mixed_img)

        # mixed_outputs = model(mixed_input)

        loss = train_criterion_BMM(label_outputs_density, mask_labels.float(), label_negative_mask.float(), corrected_mask_labels.float(), kernel_size, pi_positive, device)
        running_loss += loss.item()

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        iterations = i
        print('[%d | 9] loss: %.5f, max_value: %.5f'%(i+1,loss, label_outputs_density.max().cpu().detach().numpy()))

    t_end = time.time()
    print('\n')
    print('loss: %.5f | Time per epoch: %.2f'%(running_loss/(iterations+1),t_end-t_start))
    print('\n')
    return running_loss/(iterations+1)


def validate_regression(val_loader, model, val_criterion, kernel_size, num_data, r_thd, save_density = False, epoch = 0):
    
    model.eval()
    running_loss = 0.0
    ae = 0
    se = 0
    ct_pre = 0
    t_start = time.time()
    all_density_map = []
    all_location_gt = []
    with t.no_grad():
        for i, data in enumerate(val_loader):
    
            inputs,dot_labels,mask_labels = data[0].to(device),data[1].to(device),data[2].to(device)

            outputs_density = model(inputs)
            all_density_map.append(outputs_density.squeeze().cpu().numpy())
            all_location_gt.append(dot_labels.squeeze().cpu().numpy())

            if save_density:
                save_visualization(outputs_density[0,0,:,:].squeeze().cpu().numpy(), epoch)

            gt = t.sum(dot_labels,[2,3])
            ae += t.abs(t.sum(outputs_density,[2,3])-gt).sum()
            se += ((t.sum(outputs_density,[2,3])-gt)*(t.sum(outputs_density,[2,3])-gt)).sum()
            ct_pre += t.sum(outputs_density,[2,3]).sum()

            loss = val_criterion(outputs_density,mask_labels.float(),kernel_size)
            running_loss += loss.item()
        
        val_loss = running_loss/num_data
        val_mae = ae/num_data
        val_mse = t.sqrt(se/num_data)
        ct_mean = ct_pre/num_data

        all_density_map = np.array(all_density_map)
        all_location_gt = np.array(all_location_gt)
        all_maps = all_density_map[0]
        all_labels = all_location_gt[0]
        for j in range(len(all_density_map)-1):
            all_maps = np.append(all_maps,all_density_map[j+1],axis = 0)
            all_labels = np.append(all_labels, all_location_gt[j+1], axis = 0)

        print(all_maps.shape)
        # print(all_labels.shape)
        val_F1 = location_eval(all_maps, all_labels, r_thd, kernel_size)

    return val_loss, ct_mean, val_mae, val_mse, val_F1

def validate_CE(val_loader, model, val_criterion, kernel_size, num_data, save_density = False, epoch = 0):
    
    model.eval()
    running_loss = 0.0
    ae = 0
    se = 0
    t_start = time.time()
    with t.no_grad():
        for i, data in enumerate(val_loader):
    
            inputs,dot_labels,mask_labels = data[0].to(device),data[1].to(device),data[2].to(device)

            outputs_density = model(inputs)

            if save_density:
                save_visualization(outputs_density[0,0,:,:].squeeze().cpu().numpy(), epoch)
                print('test count: %.2f'%(outputs_density[0,0,:,:].sum()))
            gt = t.sum(dot_labels,[2,3])
            output_p = F.softmax(lossfunc.count_data(outputs_density,kernel_size,1),dim = 1)[:,0,:,:].unsqueeze(1)
            output_count = t.sum(output_p,[2,3])/(kernel_size*kernel_size)
            ae += t.abs(output_count-gt).sum()
            se += ((output_count-gt)*(output_count-gt)).sum()

            loss = val_criterion(outputs_density,mask_labels.float(),kernel_size)
            running_loss += loss.item()
        
        val_loss = running_loss/num_data
        val_mae = ae/num_data
        val_mse = t.sqrt(se/num_data)

    return val_loss, val_mae, val_mse


def save_visualization(density, epoch):
    density_img = density/max([density.max(),0.0001])*255
    density_img = np.array(density_img,dtype = np.uint8)
    cv2.imwrite('./result/density_imgs/density_' + str(epoch) + '.bmp', density_img)



def save_checkpoint(state, is_best, checkpoint='result', filename='checkpoint.pth.tar'):
    filepath = os.path.join(checkpoint, filename)
    t.save(state, filepath)
    if is_best:
        shutil.copyfile(filepath, os.path.join(checkpoint, 'model_best.pth.tar'))

if __name__ == '__main__':
    main()
