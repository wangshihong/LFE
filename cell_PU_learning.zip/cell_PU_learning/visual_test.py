import glob
import cv2
import numpy as np 
import numpy.matlib
import os
import re
import copy
from pyheatmap.heatmap import HeatMap
import torch as t
import torch.nn.functional as F




if __name__ == "__main__":
    # root = '../data/data_proc/colorectal_adenocarcinomas/'
    # root = '../data/data_proc/MBM_data/'

    root = '../data/data_proc/ucsd2000/'
    dataset = 'train'
    img_dir = root + dataset + '/imgs/'
    img_file = ['2']
    img_size = [238, 158]

    img_list = glob.glob(img_dir + '*.png')


    for _img_add in img_list:
        img = cv2.imread(_img_add)
        label_dir = _img_add.split('\\')[-1].split('.')[0] +'.txt'
        label = np.loadtxt(root + dataset + '/labels/' + label_dir)

        # for i in range(label.shape[0]):
        #     cv2.circle(img, (int(label[i][0]+0.5),int(label[i][1]+0.5)) ,1,(50,50,250),-1)
         
        b_channel, g_channel, r_channel = cv2.split(img)
        
        alpha_channel = np.ones(b_channel.shape, dtype=b_channel.dtype) * 255
        # 最小值为0
        alpha_channel[:, :int(b_channel.shape[0] / 2)] = 100
        
        img_BGRA = cv2.merge((b_channel, g_channel, r_channel, alpha_channel))

        # for i in range(len(label)):
        #     index = (min(int(label[i][1]+0.5),img_height-1),min(int(label[i][0]+0.5),img_width-1))

        #     r1 = max(0, index[0] - radius)
        #     r2 = min(index[0] + radius + 1, img_height-1)
        #     c1 = max(0, index[1] - radius)
        #     c2 = min(index[1] + radius + 1, img_width-1)
        #     label_background[r1:r2,c1:c2] = 0  #注意0，1可能会相反
        #     label_object[index[0],index[1]] = 1

        cv2.imshow('test', img_BGRA)
        cv2.waitKey()