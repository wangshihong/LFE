
from scipy.stats import beta  
import matplotlib.pyplot as plt  
import numpy as np  
import scipy.stats as stats

def weighted_mean(x, w):

    a = np.sum(w * x)
    b = np.sum(w)
    c = x.max()
    d = x.mean()
    return np.sum(w * x) / np.sum(w)

def fit_beta_weighted(x, w):
    x_bar = weighted_mean(x, w)
    s2 = weighted_mean((x - x_bar)**2, w)
    alpha = x_bar * ((x_bar * (1 - x_bar)) / s2 - 1)
    beta = alpha * (1 - x_bar) /x_bar
    return alpha, beta

class BetaMixture1D(object):
    def __init__(self, max_iters=10,
                 alphas_init=[1, 2],
                 betas_init=[2, 1],
                 weights_init=[0.5, 0.5]):
        self.alphas = np.array(alphas_init, dtype=np.float64)
        self.betas = np.array(betas_init, dtype=np.float64)
        self.weight = np.array(weights_init, dtype=np.float64)
        self.max_iters = max_iters
        self.lookup = np.zeros(100, dtype=np.float64)
        self.lookup_resolution = 100
        self.lookup_loss = np.zeros(100, dtype=np.float64)
        self.eps_nan = 1e-12

    def likelihood(self, x, y):
        return stats.beta.pdf(x, self.alphas[y], self.betas[y])

    def weighted_likelihood(self, x, y):
        return self.weight[y] * self.likelihood(x, y)

    def probability(self, x):
        return sum(self.weighted_likelihood(x, y) for y in range(2))

    def posterior(self, x, y):
        return self.weighted_likelihood(x, y) / (self.probability(x) + self.eps_nan)

    def responsibilities(self, x):
        r =  np.array([self.weighted_likelihood(x, i) for i in range(2)])
        # there are ~200 samples below that value
        r[r <= self.eps_nan] = self.eps_nan
        r /= r.sum(axis=0)
        return r

    def score_samples(self, x):
        return -np.log(self.probability(x))

    def fit(self, x):
        x = np.copy(x)
        c = x.max()
        d = x.mean()
        # EM on beta distributions unsable with x == 0 or 1
        eps = 1e-4
        x[x >= 1 - eps] = 1 - eps
        x[x <= eps] = eps

        for i in range(self.max_iters):

            # E-step
            r = self.responsibilities(x)

            # M-step
            self.alphas[0], self.betas[0] = fit_beta_weighted(x, r[0])
            self.alphas[1], self.betas[1] = fit_beta_weighted(x, r[1])
            self.weight = r.sum(axis=1)
            self.weight /= self.weight.sum()
        
        print('weight: ')
        print(self.weight)

        print('alpha, beta')
        print(self.alphas)
        print(self.betas)


        return self

    def predict(self, x):
        return self.posterior(x, 1) > 0.5

    def create_lookup(self, y):
        x_l = np.linspace(0+self.eps_nan, 1-self.eps_nan, self.lookup_resolution)
        lookup_t = self.posterior(x_l, y)
        lookup_t[np.argmax(lookup_t):] = lookup_t.max()
        self.lookup = lookup_t
        plt.plot(x_l, lookup_t, lw=2, label='mixture')
        plt.show()
        self.lookup_loss = x_l # I do not use this one at the end

    def look_lookup(self, x, loss_max, loss_min):
        x_i = x.clone().cpu().numpy()
        x_i = np.array((self.lookup_resolution * x_i).astype(int))
        x_i[x_i < 0] = 0
        x_i[x_i == self.lookup_resolution] = self.lookup_resolution - 1
        return self.lookup[x_i]

    def plot(self):
        x = np.linspace(0, 1, 100)
        plt.plot(x, self.weighted_likelihood(x, 0), label='negative')
        plt.plot(x, self.weighted_likelihood(x, 1), label='positive')
        plt.plot(x, self.probability(x), lw=2, label='mixture')
        plt.savefig('./' + 'loss_BMM.jpg')

    def __str__(self):
        return 'BetaMixture1D(w={}, a={}, b={})'.format(self.weight, self.alphas, self.betas)


if __name__ == '__main__':
    
    loss_tr = np.loadtxt('./loss.txt')

    a = loss_tr.max()
    a = loss_tr[loss_tr>0.5]
    b = loss_tr.min()

    # min_perc = np.percentile(loss_tr, 50)
    # loss_tr = loss_tr[(loss_tr>=0.01) & (loss_tr <= 0.8)]

    # # outliers detection
    max_perc = loss_tr.max() #np.percentile(loss_tr, 95)
    min_perc = 0.1
    loss_tr = loss_tr[(loss_tr<=max_perc) & (loss_tr>=min_perc)]

    c = loss_tr.max()
    d = loss_tr.mean()

    loss_tr = (loss_tr - min_perc) / (max_perc - min_perc + 1e-6)

    loss_tr[loss_tr>=1] = 1-10e-4
    loss_tr[loss_tr <= 0] = 10e-4

    hist = []
    a = loss_tr.max()
    b = loss_tr.min()
    for i in range(100):
        temp = loss_tr[loss_tr>0.01*i]
        temp = temp[temp<=0.01*(i+1)]
        hist.append(temp.size)
    
    hist = np.array(hist)

    plt.bar(range(len(hist)),hist)
    plt.show()

    bmm_model = BetaMixture1D(max_iters=10)
    bmm_model.fit(loss_tr)

    bmm_model.plot()


    bmm_model.create_lookup(1)




    a, b = 0.01880436, 1.98439994#0.01880436, 1.98439994
        
    mean, var, skew, kurt = beta.stats(a, b, moments='mvsk')  
        
    x = np.linspace(0, 1, 100)  
    plt.plot(x, beta.pdf(x, a, b), 'r-', lw=5, alpha=0.6, label='beta pdf')  
    plt.show()  

