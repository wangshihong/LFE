import torch as t
import torchvision as tv
import torchvision.transforms as transforms
import time
import os
import glob

import _init_path
from utilv2_test import test_full_img, test_full_img_CE
import network
from dataset import imgDataset

# set environment
os.environ["CUDA_VISIBLE_DEVICES"] = '0'
device = t.device("cuda:0" if t.cuda.is_available() else "cpu")
device_ids = [0]

if __name__ == '__main__':
    
    train_net = 'LIRNet'
    model_file_name = '20200916_174152'
 
    if train_net == 'LIRNet':
        count_net = network.LIRNet()
    
    # obtain data 
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
    ])

    root_dir = '../data/data_proc/colorectal_adenocarcinomas/'
    test_img_dir = root_dir + 'test/imgs/'

    test_label_dir = root_dir + 'test/labels/'
    #trainset = tv.datasets.ImageFolder(root = train_img_dir,transform = transform)
    #trainloader = t.utils.data.DataLoader(trainset,
    #                                    batch_size = 512,pin_memory = False,
    #                                    shuffle = True,num_workers = 16)
    img_list = os.listdir(test_img_dir)
    img_name_file = open('./result/img_name.txt','w')
    for i in range(len(img_list)):
        img_name_file.write(str(img_list[i])+'\n')
    img_name_file.close()

    testset = imgDataset(test_img_dir,test_label_dir, 7, transform, train = False)
    testloader = t.utils.data.DataLoader(testset,
                                        batch_size = 1,pin_memory = False,
                                        shuffle = False,num_workers = 1)

    print('The numbers of samples in test dataset is: %d'%(len(testset)))

    count_net = t.nn.DataParallel(count_net,device_ids = device_ids)

    save_add = './save_model/' + train_net + '/' + model_file_name + '/'
    count_net.load_state_dict(t.load(save_add + train_net + '-epoch_200.pt'))
    
    count_net.to(device)
    patch_size = 25
    #validate(testloader,count_net,device,'test set',save_add,patch_size,save_fig = False)
    test_full_img(testloader,count_net,device,'test set',save_add,save_fig = False)
